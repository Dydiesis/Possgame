# PossMiner – Frontiera Mineraria (Android)

Gioco idle minerario originale sviluppato da zero in Java Android, offline, senza advertising SDK, analytics, acquisti in-app, login o permessi di rete.

## Caratteristiche
- 6 siti minerari sbloccabili, animazione originale del pianeta e dei droni.
- Estrazione, depositi, trasporto e inventario che si aggiornano automaticamente.
- Upgrade separati di trapani, navette e silos.
- Vendita risorse, raffinazione di minerali e vendita delle leghe.
- Ricerca globale, vendita e raffinazione automatica sbloccabili con crediti di gioco.
- Obiettivi con ricompense, accumulo risorse offline fino a 8 ore.
- Salvataggio locale, nessuna pubblicità / acquisti integrati.

Progetto indipendente. Non contiene materiali grafici, file, codice, musiche, loghi o personaggi di ExoMiner.

## Build
Requisiti: JDK 17, Android SDK 35, Gradle 8.11.1.
`gradle :app:assembleDebug`
APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Licenza
Codice di nuova realizzazione; non contiene componenti proprietari provenienti da giochi terzi.
