# PossMiner Frontiera 2.0 – Gioco idle industriale originale

Applicazione Android Java, offline e senza pubblicità, acquisti, analytics o permessi Internet.

## In questa versione
- 18 giacimenti con risorse primarie e secondarie, silo locale e vere navette con tempi di viaggio e capacità di carico.
- 12 minerali con valori progressivi; magazzino centrale e gestione riserve.
- 10 ricette di raffinazione, 10 progetti di componenti con distinte base a più stadi.
- Code di produzione, avanzamento dei lavori anche offline e fino a tre linee di lavoro per impianto.
- 14 tecnologie con dipendenze, 8 specialisti permanenti e assegnazione a siti.
- 20 ranghi per pianeta, missioni multiobiettivo, 3 contratti commerciali ripetibili con scienza e crediti.
- Viaggi su pianeti generativi e bonus permanenti; boost comprabili soltanto con premi di gioco.
- Progressione offline fino a 12 ore con salvataggio automatico; mappa planetaria originale interattiva.
- Moltiplicatori x1, x10, MAX per i potenziamenti.

## Copyright
Codice e grafica sviluppati ex novo. Il genere idle minerario e le sue meccaniche astratte sono il riferimento: nessun file, immagine, nome, testo, musica, marchio o dato proprietario di ExoMiner è stato riutilizzato.

## Compilazione
JDK 17, Gradle 8.11.1, Android SDK 35: `gradle :app:assembleDebug`.

## Installazione
ID applicazione: `it.poss.miner.frontier` (installabile accanto al precedente PossMiner 1.0 senza cancellarne i dati).
