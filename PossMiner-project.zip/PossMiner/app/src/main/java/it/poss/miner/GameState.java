package it.poss.miner;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/** The complete, original PossMiner simulation. No networking or ad integration. */
public final class GameState {
    public static final int N = 6;
    public static final String[] SITES = {"CRATERE AURORA", "DUNA PRISMATICA", "FAGLIA BLU", "ARCO BOREALE", "BACINO RUBINO", "NUCLEO OMBRA"};
    public static final String[] ORES = {"Ferro", "Rame", "Quarzo", "Titanio", "Cobalto", "Iridio"};
    public static final String[] ICONS = {"Fe", "Cu", "Si", "Ti", "Co", "Ir"};
    public static final int[] COLORS = {0xFF77E0F7,0xFFFFAD78,0xFFB9A8FF,0xFF67EAD0,0xFFFF8FAD,0xFFFFD26F};
    public static final double[] BASE_RATE = {1.25,.92,.61,.39,.23,.11};
    public static final int[] VALUE = {4,10,25,60,145,360};
    public static final double[] OPEN_COST = {0,560,2700,11700,49000,190000};
    public static final double[] DRILL_COST = {75,240,850,2900,9000,32000};
    public static final double[] DRONE_COST = {58,180,600,2200,6800,23500};
    public static final double[] SILO_COST = {42,110,480,1700,5500,17000};
    public static final String[] MISSION_NAMES = {"Primi passi", "Una montagna di minerali", "La prima rotta commerciale", "Nuovi orizzonti", "Metallo stellare", "Capitano d'industria", "Espansione interplanetaria", "La grande produzione"};
    public static final String[] MISSION_DESCS = {"Acquista 2 potenziamenti per le miniere", "Estrai 35 unità di minerali", "Vendi 45 unità di risorse", "Sblocca 2 siti minerari", "Raffina 12 lingotti", "Guadagna 9.000 crediti totali", "Sblocca 4 siti minerari", "Estrai 8.000 unità di minerali"};
    public static final int[] MISSION_TYPES = {0,1,2,3,4,5,3,1};
    public static final double[] MISSION_GOALS = {2,35,45,2,12,9000,4,8000};
    public static final double[] MISSION_REWARDS = {180,250,450,700,900,2000,5500,18000};

    public double credits=240;
    public double totalMined=0, totalSold=0, totalRefined=0, totalEarned=0;
    public int upgrades=0, researchDrill=0, researchTransit=0, mission=0;
    public boolean autoSellOwned=false, autoSell=false, autoRefineOwned=false, autoRefine=false;
    public double saleTimer=0, refineTimer=0;
    public final boolean[] unlocked=new boolean[N];
    public final int[] drills=new int[N], drones=new int[N], silos=new int[N];
    public final double[] onSite=new double[N], raw=new double[N], ingots=new double[N];
    public long lastTime=System.currentTimeMillis();
    public double offlineProduction=0;

    public GameState() {
        unlocked[0]=true;
        for(int i=0;i<N;i++){ drills[i]=1; drones[i]=1; silos[i]=1; }
    }

    public static GameState load(Context context) {
        GameState s=new GameState();
        SharedPreferences p=context.getSharedPreferences("possminer_save_v1", Context.MODE_PRIVATE);
        String blob=p.getString("state",null);
        if(blob==null)return s;
        try {
            JSONObject j=new JSONObject(blob);
            s.credits=Math.max(0,j.optDouble("credits",240));
            s.totalMined=Math.max(0,j.optDouble("totalMined",0));
            s.totalSold=Math.max(0,j.optDouble("totalSold",0));
            s.totalRefined=Math.max(0,j.optDouble("totalRefined",0));
            s.totalEarned=Math.max(0,j.optDouble("totalEarned",0));
            s.upgrades=j.optInt("upgrades",0);
            s.researchDrill=j.optInt("researchDrill",0);
            s.researchTransit=j.optInt("researchTransit",0);
            s.mission=Math.max(0,Math.min(MISSION_NAMES.length,j.optInt("mission",0)));
            s.autoSellOwned=j.optBoolean("autoSellOwned",false);
            s.autoSell=j.optBoolean("autoSell",false)&&s.autoSellOwned;
            s.autoRefineOwned=j.optBoolean("autoRefineOwned",false);
            s.autoRefine=j.optBoolean("autoRefine",false)&&s.autoRefineOwned;
            s.saleTimer=j.optDouble("saleTimer",0);
            s.refineTimer=j.optDouble("refineTimer",0);
            s.lastTime=j.optLong("lastTime",System.currentTimeMillis());
            JSONArray arr=j.optJSONArray("mines");
            if(arr!=null)for(int i=0;i<Math.min(N,arr.length());i++){
                JSONObject m=arr.optJSONObject(i);
                if(m==null)continue;
                s.unlocked[i]=m.optBoolean("unlocked",i==0);
                s.drills[i]=Math.max(1,m.optInt("drill",1));
                s.drones[i]=Math.max(1,m.optInt("drone",1));
                s.silos[i]=Math.max(1,m.optInt("silo",1));
                s.onSite[i]=Math.max(0,m.optDouble("site",0));
                s.raw[i]=Math.max(0,m.optDouble("raw",0));
                s.ingots[i]=Math.max(0,m.optDouble("ingot",0));
            }
            s.unlocked[0]=true;
        }catch(Exception ignored){return new GameState();}
        return s;
    }

    public void save(Context context){
        try {
            JSONObject j=new JSONObject();
            j.put("credits",credits);j.put("totalMined",totalMined);j.put("totalSold",totalSold);
            j.put("totalRefined",totalRefined);j.put("totalEarned",totalEarned);
            j.put("upgrades",upgrades);j.put("researchDrill",researchDrill);j.put("researchTransit",researchTransit);
            j.put("mission",mission);j.put("autoSellOwned",autoSellOwned);j.put("autoSell",autoSell);
            j.put("autoRefineOwned",autoRefineOwned);j.put("autoRefine",autoRefine);
            j.put("saleTimer",saleTimer);j.put("refineTimer",refineTimer);j.put("lastTime",lastTime);
            JSONArray mines=new JSONArray();
            for(int i=0;i<N;i++){
                JSONObject m=new JSONObject();m.put("unlocked",unlocked[i]);m.put("drill",drills[i]);m.put("drone",drones[i]);
                m.put("silo",silos[i]);m.put("site",onSite[i]);m.put("raw",raw[i]);m.put("ingot",ingots[i]);
                mines.put(m);
            }
            j.put("mines",mines);
            context.getSharedPreferences("possminer_save_v1",Context.MODE_PRIVATE).edit().putString("state",j.toString()).apply();
        }catch(Exception ignored){}
    }

    public double rate(int i){ return BASE_RATE[i]*(1+0.52*(drills[i]-1))*Math.pow(1.2,researchDrill); }
    public double transit(int i){ return BASE_RATE[i]*1.45*(1+0.48*(drones[i]-1))*Math.pow(1.2,researchTransit); }
    public double cap(int i){return 12+18.0*(silos[i]-1);}
    public int opened(){int count=0;for(boolean b:unlocked)if(b)count++;return count;}
    public double drillPrice(int i){return Math.ceil(DRILL_COST[i]*Math.pow(1.68,drills[i]-1));}
    public double dronePrice(int i){return Math.ceil(DRONE_COST[i]*Math.pow(1.6,drones[i]-1));}
    public double siloPrice(int i){return Math.ceil(SILO_COST[i]*Math.pow(1.58,silos[i]-1));}
    public double researchDrillPrice(){return Math.ceil(460*Math.pow(2.3,researchDrill));}
    public double researchTransitPrice(){return Math.ceil(400*Math.pow(2.3,researchTransit));}

    public boolean buyMine(int i){if(i<=0||i>=N||unlocked[i]||credits+1e-6<OPEN_COST[i])return false;credits-=OPEN_COST[i];unlocked[i]=true;return true;}
    public boolean buyUpgrade(int i,int what){
        if(i<0||i>=N||!unlocked[i])return false;
        double price=what==0?drillPrice(i):what==1?dronePrice(i):siloPrice(i);
        if(credits+1e-6<price)return false;
        credits-=price;
        if(what==0)drills[i]++;else if(what==1)drones[i]++;else silos[i]++;
        upgrades++;
        return true;
    }
    public boolean buyResearch(int which){
        double price=which==0?researchDrillPrice():researchTransitPrice();
        if(credits+1e-6<price)return false;
        credits-=price;if(which==0)researchDrill++;else researchTransit++;
        upgrades++;return true;
    }
    public boolean buyAutomation(int which){
        double cost=which==0?2900:4700;
        if(credits+1e-6<cost)return false;
        if(which==0){if(autoSellOwned)return false;credits-=cost;autoSellOwned=true;autoSell=true;}
        else {if(autoRefineOwned)return false;credits-=cost;autoRefineOwned=true;autoRefine=true;}
        return true;
    }
    public double sell(int i,boolean refined){
        if(i<0||i>=N)return 0;
        double have=refined?ingots[i]:raw[i];
        double units=Math.floor(have+1e-8);
        if(units<=0)return 0;
        if(refined)ingots[i]-=units;else raw[i]-=units;
        double sum=units*VALUE[i]*(refined?5.5:1);
        credits+=sum;totalEarned+=sum;totalSold+=units;
        return sum;
    }
    public int refine(int i,int qty){
        if(i<0||i>=N || qty<=0)return 0;
        int batches=Math.min(qty,(int)Math.floor((raw[i]+1e-8)/4));
        if(batches<1)return 0;
        raw[i]-=batches*4.0;ingots[i]+=batches;totalRefined+=batches;
        return batches;
    }

    /** Simulates production analytically so the game also advances while closed. */
    public void advance(double seconds) {
        if(seconds<=0)return;
        seconds=Math.min(seconds,8*3600);
        for(int i=0;i<N;i++){
            if(!unlocked[i])continue;
            double extracted=rate(i)*seconds;
            double availability=onSite[i]+extracted;
            double moved=Math.min(availability,transit(i)*seconds);
            onSite[i]=Math.min(cap(i),Math.max(0,availability-moved));
            raw[i]+=moved;
            totalMined+=extracted;
        }
        if(autoRefine){
            refineTimer+=seconds;
            long cycles=(long)(refineTimer/2.0);
            if(cycles>0){
                refineTimer-=cycles*2.0;
                for(int i=0;i<N;i++)if(unlocked[i])refine(i,(int)Math.min(100000,cycles));
            }
        }
        if(autoSell){
            saleTimer+=seconds;
            if(saleTimer>=12){
                saleTimer%=12;
                for(int i=0;i<N;i++)if(unlocked[i]){
                    sell(i,false);sell(i,true);
                }
            }
        }
    }
    public void advanceToNow(){
        long now=System.currentTimeMillis();
        long elapsed=now-lastTime;
        if(elapsed>0){
            offlineProduction=totalMined;
            advance(Math.min(elapsed/1000.0,8*3600));
            offlineProduction=Math.max(0,totalMined-offlineProduction);
        }
        lastTime=now;
    }
    public double missionProgress(){
        if(mission>=MISSION_TYPES.length)return 0;
        switch(MISSION_TYPES[mission]){
            case 0: return upgrades;
            case 1: return totalMined;
            case 2: return totalSold;
            case 3: return opened();
            case 4: return totalRefined;
            default: return totalEarned;
        }
    }
    public boolean missionReady(){return mission<MISSION_GOALS.length&&missionProgress()+1e-6>=MISSION_GOALS[mission];}
    public double claimMission(){
        if(!missionReady())return 0;
        double reward=MISSION_REWARDS[mission];credits+=reward;mission++;
        return reward;
    }
    public static String num(double v){
        double a=Math.abs(v);
        if(a>=1_000_000_000)return String.format(Locale.ITALY,"%.2fG",v/1_000_000_000);
        if(a>=1_000_000)return String.format(Locale.ITALY,"%.2fM",v/1_000_000);
        if(a>=10_000)return String.format(Locale.ITALY,"%.1fk",v/1000);
        return String.format(Locale.ITALY,"%,.0f",Math.floor(v));
    }
    public static String decimal(double v){return String.format(Locale.ITALY,"%.1f",v);}
}
