package it.poss.miner;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;
import java.util.Arrays;

/** An original, self-contained industrial colony simulation. No network, ad or paid APIs. */
public final class FrontierGame {
    public static final int DEPOSITS=18, ORES=12, ALLOYS=10, PARTS=10, TECHS=14, CREW=8, SLOTS=3;
    public static final String[] PLANETS={"NEREIDE","CALDERA","ASTERION","SOLSTIZIO","HALCYON","PERSEO","VEGA","ORIONE"};
    public static final int[] PLANET_COLORS={0xFF51D6CE,0xFFF89C5F,0xFF91AEFF,0xFFB19AFF,0xFF65D5A1,0xFFFCB3CA,0xFFF2C769,0xFF6FCFF9};
    public static final String[] ORE={"Ferrite","Rame","Silice","Cobalto","Titanio","Nichel","Litio","Bismuto","Platino","Iridio","Osmio","Xenite"};
    public static final String[] ORE_SYMBOL={"Fe","Cu","Si","Co","Ti","Ni","Li","Bi","Pt","Ir","Os","Xe"};
    public static final int[] ORE_COLOR={0xFF80D8EB,0xFFF4A46B,0xFFB7B5FF,0xFF80F3CE,0xFFDFA8F3,0xFFB2D18B,0xFFFFD36E,0xFFE7AB8B,0xFFAEDEF4,0xFF98ABE9,0xFFEAADB5,0xFF68E3E2};
    public static final int[] ORE_PRICE={4,9,17,33,60,115,200,380,670,1200,2350,4250};
    public static final String[] ZONES={"Cratere Vento","Spina Polare","Piana Vetrata","Arco Zenith","Delta Profonda","Scogliera Ignea","Settore Fossile","Duna Circolare","Grotta Pulsar","Fossa Boreale","Anello Iris","Catena Celeste","Piana Draconica","Faglia Rossa","Picco Elementale","Valle Aurora","Cuore Scuro","Zona Zero"};
    public static final double[] ACCESS={0,230,950,3900,14000,48000,164000,580000,1900000,6100000,19600000,62000000,190000000,560000000,1500000000,4100000000d,11000000000d,30000000000d};
    public static final String[] ALLOY={"Lega ferrica","Bronzo stellare","Vetro siliceo","Cobalto puro","Titanio temperato","Nichel puro","Celle al litio","Bismuto raffinato","Platino laminato","Iridio ionizzato"};
    public static final String[] PART={"Giunto magnetico","Cella d'impulso","Sensore spettrale","Turbina ausiliaria","Braccio minerario","Motore stellare","Matrice logica","Modulo gravitico","Sistema di navigazione","Cuore quantico"};
    public static final double[] ALLOY_TIME={18,26,35,49,66,88,116,158,210,280};
    public static final double[] PART_TIME={34,55,80,115,160,220,305,420,580,830};
    public static final double[] PART_VALUE={340,880,2100,5700,13500,36000,88000,245000,600000,1900000};
    public static final String[] TECH_NAMES={"Sensori minerari","Piloti automatici","Cargo espanso","Fornaci a impulsi","Doppia fonderia","Assemblaggio rapido","Doppio cantiere","Mercato automatico","Risonanza geologica","Recupero termico","Archivi scientifici","Hangar avanzato","Terza fonderia","Terzo cantiere"};
    public static final String[] TECH_DESC={"+25% estrazione in ogni giacimento","Navette del 25% più rapide","+50% carico per viaggio","Fonderia del 25% più veloce","Seconda linea di raffinazione","Costruzione del 25% più rapida","Seconda linea di costruzione","Vende automaticamente il grezzo in eccesso","+35% estrazione su tutti i siti","Riduce del 20% il consumo delle raffinerie","+1 punto scienza ogni contratto","+25% velocità navette su ogni pianeta","Terza linea di raffinazione","Terza linea di costruzione"};
    public static final int[] TECH_SCIENCE={3,4,4,6,9,8,12,10,15,15,18,20,36,44};
    public static final double[] TECH_CREDITS={800,1350,2500,4800,14000,19000,60000,28000,145000,190000,250000,350000,800000,1200000};
    public static final int[] TECH_REQUIRES={-1,-1,1,-1,3,-1,5,1,0,3,8,2,4,6};
    public static final String[] CREW_NAME={"Aria","Dax","Mira","Soren","Eko","Yuna","Rho","Lyra"};
    public static final String[] CREW_ROLE={"Geologa","Pilota","Capotecnica","Chimico","Progettista","Mercante","Ricercatore","Esploratrice"};
    public static final String[] CREW_BONUS={"+35% estrazione del sito assegnato","+45% velocità navetta nel sito","+50% capienza della navetta assegnata","+20% velocità della fonderia","+20% velocità del cantiere","+12% ricavi dalle vendite","+20% punti scienza dai contratti","+15% estrazione globale"};
    public static final int[] CREW_PRICE={2,3,3,4,5,6,7,8};
    public static final String[] RANK_DESCRIPTIONS={
       "Acquista 2 potenziamenti dei macchinari","Estrai 120 minerali","Apri 2 giacimenti","Raffina 3 lotti di minerale",
       "Costruisci 1 componente","Guadagna 1.800 CR con le vendite","Sblocca una ricerca tecnologica","Estrai altri 900 minerali",
       "Apri 4 giacimenti","Costruisci altri 4 componenti","Completa 2 contratti commerciali","Acquista altri 15 potenziamenti",
       "Raffina altri 25 lotti","Sblocca 4 ricerche tecnologiche","Apri 8 giacimenti","Costruisci altri 15 componenti",
       "Estrai altri 25.000 minerali","Guadagna altri 500.000 CR","Completa altri 6 contratti","Costruisci altri 35 componenti"};

    public int planet=0, rank=1, science=0, stars=0, contractSequence=0, contractsDone=0, upgrades=0, refinedDone=0, madeDone=0;
    public int marketReserve=0, productionMode=0, selectedMine=0, upgradeAmount=1;
    public double credits=650,totalMined=0,totalDelivered=0,totalEarned=0,totalSold=0, totalTime=0;
    public double prestigeBonus=1, speedBoostRemaining=0, timeOffline=0, idleProduced=0;
    public long lastMs=System.currentTimeMillis();
    public final boolean[] open=new boolean[DEPOSITS], tech=new boolean[TECHS], hired=new boolean[CREW];
    public final int[] drill=new int[DEPOSITS], ship=new int[DEPOSITS], cargo=new int[DEPOSITS], crewAssigned=new int[CREW], refQueue=new int[ALLOYS], partQueue=new int[PARTS], plans=new int[PARTS];
    public final double[] hopper=new double[DEPOSITS], freight=new double[DEPOSITS], flight=new double[DEPOSITS], raw=new double[ORES], alloys=new double[ALLOYS], parts=new double[PARTS];
    public final int[] refineryJob=new int[SLOTS], constructorJob=new int[SLOTS], contractResource=new int[3], contractKind=new int[3];
    public final double[] refineryTime=new double[SLOTS], constructorTime=new double[SLOTS], contractQty=new double[3], contractReward=new double[3];
    public final int[] contractScience=new int[3];
    public final double[] missionStart=new double[5];
    public int tutorialStage=0; public boolean sound=false;

    public FrontierGame(){
      open[0]=true;open[1]=false;
      Arrays.fill(drill,1);Arrays.fill(ship,1);Arrays.fill(cargo,1);Arrays.fill(crewAssigned,-1);
      Arrays.fill(refineryJob,-1); Arrays.fill(constructorJob,-1);plans[0]=1;plans[1]=1;
      for(int n=0;n<3;n++)renewContract(n);
      captureMissionStart();
    }
    public String planetName(){return PLANETS[planet%PLANETS.length]+(planet>=PLANETS.length?" "+(planet/PLANETS.length+1):"");}
    public int planetColor(){return PLANET_COLORS[planet%PLANET_COLORS.length];}
    public double planetMultiplier(){return Math.pow(2.6,planet);}
    public int oreOf(int i){return Math.min(ORES-1, Math.max(0, i<12?i:i-4));}
    public int secondOre(int i){return Math.min(ORES-1,oreOf(i)+1);}
    public double openCost(int i){return ACCESS[i]*Math.pow(3.1,planet);}
    public double rate(int i){
      double base=(0.38+0.16*Math.sin(i*1.78))*Math.pow(1.11,i)*Math.pow(1.28,planet);
      double value=base*Math.pow(1.38,drill[i]-1)*(tech[0]?1.25:1)*(tech[8]?1.35:1)*(hired[7]?1.15:1);
      if(hired[0]&&crewAssigned[0]==i)value*=1.35;
      if(speedBoostRemaining>0)value*=2.0;
      return value;
    }
    public double tripDuration(int i){
      double speed=Math.pow(1.18,ship[i]-1)*(tech[1]?1.25:1)*(tech[11]?1.25:1);
      if(hired[1]&&crewAssigned[1]==i)speed*=1.45;
      return Math.max(1.2,(7.5+i*0.95)/speed);
    }
    public double carry(int i){
      double v=(7+3*(cargo[i]-1))*(tech[2]?1.5:1);
      return hired[2]&&crewAssigned[2]==i?v*1.5:v;
    }
    public double cap(int i){return 25+5*drill[i]+7*cargo[i];}
    public double price(int i,int kind){
      double seed=(kind==0?78:kind==1?70:56)*Math.pow(2.55,i/3.0)*Math.pow(3.0,planet);
      int lv=kind==0?drill[i]:kind==1?ship[i]:cargo[i];
      return Math.ceil(seed*Math.pow(kind==0?1.67:1.57,lv-1));
    }
    public boolean buyDeposit(int i){if(i<1||i>=DEPOSITS||open[i]||credits<openCost(i))return false;credits-=openCost(i);open[i]=true;return true;}
    public int buyUpgrade(int i,int kind,int count){
      if(i<0||i>=DEPOSITS||!open[i])return 0;
      int bought=0,max=count==999?250:count;
      while(bought<max){double cost=price(i,kind);if(cost>credits || !Double.isFinite(cost))break;credits-=cost;bought++;upgrades++;
        if(kind==0)drill[i]++;else if(kind==1)ship[i]++;else cargo[i]++;}
      return bought;
    }
    public int opened(){int n=0;for(boolean x:open)if(x)n++;return n;}
    public int techCount(){int n=0;for(boolean x:tech)if(x)n++;return n;}
    public int hiredCount(){int n=0;for(boolean x:hired)if(x)n++;return n;}
    public boolean buyTech(int i){
      if(i<0||i>=TECHS||tech[i] || (TECH_REQUIRES[i]>=0&&!tech[TECH_REQUIRES[i]]) || credits<TECH_CREDITS[i]*planetMultiplier() ||science<TECH_SCIENCE[i])return false;
      credits-=TECH_CREDITS[i]*planetMultiplier();science-=TECH_SCIENCE[i];tech[i]=true;return true;
    }
    public boolean buyCrew(int i){if(i<0||i>=CREW||hired[i]||stars<CREW_PRICE[i])return false;stars-=CREW_PRICE[i];hired[i]=true;return true;}
    public void assignCrew(int i,int mine){if(i<0||i>=3||!hired[i])return; crewAssigned[i]=mine>=0&&mine<DEPOSITS&&open[mine]?mine:-1;}
    public boolean buyBlueprint(int id){if(id<0||id>=PARTS||plans[id]==1)return false;
      double p=850*Math.pow(3.7,id)*planetMultiplier();if(credits<p)return false;credits-=p;plans[id]=1;return true;}
    public double oreValue(int i){return ORE_PRICE[i]*planetMultiplier();}
    public double partValue(int i){return PART_VALUE[i]*planetMultiplier();}
    public double refinerySpeed(){return (tech[3]?1.25:1)*(hired[3]?1.20:1);}
    public double constructorSpeed(){return (tech[5]?1.25:1)*(hired[4]?1.20:1);}
    public int refinerySlots(){return 1+(tech[4]?1:0)+(tech[12]?1:0);}
    public int builderSlots(){return 1+(tech[6]?1:0)+(tech[13]?1:0);}
    public int alloyCost(int recipe){return (recipe<3?8:recipe<7?12:18) - (tech[9]?2:0);}
    public double alloyPrice(int recipe){return ORE_PRICE[recipe]*3.25*planetMultiplier();}
    public double marketBonus(){return hired[5]?1.12:1.0;}
    public boolean queueRefining(int recipe,int qty){if(recipe<0||recipe>=ALLOYS||qty<1||refQueue[recipe]+qty>999)return false;refQueue[recipe]+=qty;startJobs();return true;}
    public boolean queueCrafting(int recipe,int qty){if(recipe<0||recipe>=PARTS||plans[recipe]==0||qty<1||partQueue[recipe]+qty>999)return false;partQueue[recipe]+=qty;startJobs();return true;}
    public void cancelQueue(boolean refinery,int recipe){if(refinery){if(recipe>=0&&recipe<ALLOYS)refQueue[recipe]=0;}else if(recipe>=0&&recipe<PARTS)partQueue[recipe]=0;}
    public int[] partAlloyNeeds(int id){
      int[] needs=new int[ALLOYS];int primary=Math.min(ALLOYS-1,(id+1)/2),secondary=Math.max(0,primary-1);
      needs[primary]=2+id/3;needs[secondary]+=id<3?1:2;
      if(id>=5)needs[Math.min(ALLOYS-1,primary+1)]+=1;
      return needs;
    }
    public int[] partComponentNeeds(int id){int[] needs=new int[PARTS];if(id>=2)needs[id-2]=1+id/4; if(id>=4)needs[id-3]=1;return needs;}
    public boolean canStartRef(int id){return id>=0&&id<ALLOYS&&raw[id]>=alloyCost(id);}
    public boolean canStartPart(int id){if(id<0||id>=PARTS||plans[id]!=1)return false;int[] a=partAlloyNeeds(id),b=partComponentNeeds(id);
      for(int n=0;n<ALLOYS;n++)if(alloys[n]+1e-6<a[n])return false;
      for(int n=0;n<PARTS;n++)if(parts[n]+1e-6<b[n])return false;
      return true;}
    private void startJobs(){
      for(int k=0;k<refinerySlots();k++)if(refineryJob[k]<0){
        for(int i=0;i<ALLOYS;i++)if(refQueue[i]>0&&canStartRef(i)){
          raw[i]-=alloyCost(i);refQueue[i]--;refineryJob[k]=i;refineryTime[k]=ALLOY_TIME[i]/refinerySpeed();break;
        }
      }
      for(int k=0;k<builderSlots();k++)if(constructorJob[k]<0){
        for(int i=0;i<PARTS;i++)if(partQueue[i]>0&&canStartPart(i)){
          int[] a=partAlloyNeeds(i),b=partComponentNeeds(i);
          for(int n=0;n<ALLOYS;n++)alloys[n]-=a[n];
          for(int n=0;n<PARTS;n++)parts[n]-=b[n];
          partQueue[i]--;constructorJob[k]=i;constructorTime[k]=PART_TIME[i]/constructorSpeed();break;
        }
      }
    }
    public double sell(int kind,int id,int amount){
      if(amount<1)return 0;
      double[] inventory=kind==0?raw:kind==1?alloys:parts;
      if(id<0||id>=inventory.length)return 0;
      double units=Math.min(Math.floor(inventory[id]),amount==999999?Double.MAX_VALUE:amount);
      if(units<=0)return 0;
      inventory[id]-=units;
      double value=(kind==0?oreValue(id):kind==1?alloyPrice(id):partValue(id))*units*marketBonus();
      credits+=value;totalEarned+=value;totalSold+=units;return value;
    }
    public void sellEverythingRaw(){for(int i=0;i<ORES;i++)sell(0,i,999999);}
    public void sellEverythingAlloys(){for(int i=0;i<ALLOYS;i++)sell(1,i,999999);}
    public String contractLabel(int n){int k=contractKind[n],res=contractResource[n];return (k==0?ORE[res]:k==1?ALLOY[res]:PART[res]);}
    public double contractHave(int n){int k=contractKind[n],res=contractResource[n];return (k==0?raw[res]:k==1?alloys[res]:parts[res]);}
    public void renewContract(int n){
      int seq=contractSequence++;
      int tier=Math.max(1,opened());
      int kind=(seq%5==0&&plans[0]==1)?2:(seq%3==0?1:0);
      int id=kind==0?Math.min(ORES-1,seq%tier):kind==1?Math.min(ALLOYS-1,(seq+1)%Math.min(tier,ALLOYS)):0;
      contractKind[n]=kind;contractResource[n]=id;
      contractQty[n]=kind==0?Math.max(15,22+seq*6+planet*12):kind==1?Math.min(70,2+seq/4):1+(seq/6)%3;
      double rate=kind==0?oreValue(id):kind==1?alloyPrice(id):partValue(id);
      contractReward[n]=Math.ceil(contractQty[n]*rate*(kind==2?2.1:1.7));contractScience[n]=2+(seq/4)%4 + (tech[10]?1:0);
    }
    public boolean deliverContract(int slot){
      if(slot<0||slot>=3||contractHave(slot)+1e-8<contractQty[slot])return false;
      double[] inv=contractKind[slot]==0?raw:contractKind[slot]==1?alloys:parts;
      inv[contractResource[slot]]-=contractQty[slot];credits+=contractReward[slot];totalEarned+=contractReward[slot];science+=contractScience[slot];contractsDone++;
      if(contractsDone%5==0)stars++;
      renewContract(slot);return true;
    }
    public boolean refreshContract(int slot){if(slot<0||slot>=3||science<1)return false;science--;renewContract(slot);return true;}
    public double missionProgress(){switch(rank){
      case 1:case 12:return upgrades;
      case 2:case 8:case 17:return totalMined;
      case 3:case 9:case 15:return opened();
      case 4:case 13:return refinedDone;
      case 5:case 10:case 16:case 20:return madeDone;
      case 6:case 18:return totalEarned;
      case 7:case 14:return techCount();
      case 11:case 19:return contractsDone;
      default:return 1;
    }}
    public double missionTarget(){switch(rank){
      case 1:return missionStart[0]+2;case 2:return missionStart[1]+120;case 3:return 2;
      case 4:return missionStart[2]+3;case 5:return missionStart[3]+1;
      case 6:return missionStart[4]+1800;case 7:return 1;case 8:return missionStart[1]+900;
      case 9:return 4;case 10:return missionStart[3]+4;case 11:return missionContractsStart+2;
      case 12:return missionStart[0]+15;case 13:return missionStart[2]+25;
      case 14:return 4;case 15:return 8;case 16:return missionStart[3]+15;
      case 17:return missionStart[1]+25000;case 18:return missionStart[4]+500000;
      case 19:return missionContractsStart+6;case 20:return missionStart[3]+35;
      default:return 1;
    }}
    private int missionContractsStart=0;
    public boolean canClaimRank(){return rank<=20&&missionProgress()+1e-6>=missionTarget();}
    public boolean claimRank(){if(!canClaimRank())return false;science+=3+rank/4;stars+=rank%5==0?3:1;
      credits+=250*Math.pow(1.72,rank-1)*planetMultiplier();rank++;captureMissionStart();return true;}
    public boolean canTravel(){return rank>20;}
    public boolean nextPlanet(){if(!canTravel())return false;
      planet++;prestigeBonus=Math.pow(1.40,planet);credits=650*planetMultiplier();science+=8;stars+=5;
      totalMined=totalEarned=totalSold=totalDelivered=0;upgrades=refinedDone=madeDone=0;rank=1;
      Arrays.fill(open,false);open[0]=true;Arrays.fill(drill,1);Arrays.fill(ship,1);Arrays.fill(cargo,1);
      Arrays.fill(hopper,0);Arrays.fill(freight,0);Arrays.fill(flight,0);
      Arrays.fill(raw,0);Arrays.fill(alloys,0);Arrays.fill(parts,0);
      Arrays.fill(refQueue,0);Arrays.fill(partQueue,0);Arrays.fill(refineryJob,-1);Arrays.fill(constructorJob,-1);
      Arrays.fill(refineryTime,0);Arrays.fill(constructorTime,0);
      Arrays.fill(tech,false);Arrays.fill(plans,0);plans[0]=plans[1]=1;Arrays.fill(crewAssigned,-1);
      contractSequence=0;contractsDone=0;selectedMine=0;speedBoostRemaining=0;
      for(int n=0;n<3;n++)renewContract(n);captureMissionStart();return true;
    }
    public void captureMissionStart(){missionStart[0]=upgrades;missionStart[1]=totalMined;missionStart[2]=refinedDone;missionStart[3]=madeDone;missionStart[4]=totalEarned;missionContractsStart=contractsDone;}
    public boolean startBoost(){if(stars<2||speedBoostRemaining>0)return false;stars-=2;speedBoostRemaining=10*60;return true;}
    public double ratePerMinute(){double v=0;for(int i=0;i<DEPOSITS;i++)if(open[i])v+=rate(i)*60;return v;}
    public double warehouseTotal(){double sum=0;for(double a:raw)sum+=a;return sum;}
    public double inventoryWorth(){double sum=0;for(int i=0;i<ORES;i++)sum+=raw[i]*oreValue(i);for(int i=0;i<ALLOYS;i++)sum+=alloys[i]*alloyPrice(i);for(int i=0;i<PARTS;i++)sum+=parts[i]*partValue(i);return sum;}
    public void advance(double seconds){
      if(seconds<=0)return;
      seconds=Math.min(seconds,12*3600);
      while(seconds>0){double dt=Math.min(2.0,seconds);seconds-=dt;totalTime+=dt;
        speedBoostRemaining=Math.max(0,speedBoostRemaining-dt);
        for(int i=0;i<DEPOSITS;i++){
          if(!open[i])continue;
          if(flight[i]>0){flight[i]-=dt;
            if(flight[i]<=0){double delivered=freight[i];freight[i]=0;flight[i]=0;
              raw[oreOf(i)]+=delivered*(i%4==0?0.9:1);
              if(i%4==0&&secondOre(i)!=oreOf(i))raw[secondOre(i)]+=delivered*.1;
              totalDelivered+=delivered;
            }
          }
          double extraction=Math.min(rate(i)*dt,Math.max(0,cap(i)-hopper[i]));
          hopper[i]+=extraction;totalMined+=extraction;
          if(flight[i]<=0&&hopper[i]>=0.75){
            double load=Math.min(hopper[i],carry(i));hopper[i]-=load;freight[i]=load;flight[i]=tripDuration(i);
          }
        }
        for(int n=0;n<refinerySlots();n++)if(refineryJob[n]>=0){
          refineryTime[n]-=dt;
          if(refineryTime[n]<=0){alloys[refineryJob[n]]++;refinedDone++;refineryJob[n]=-1;refineryTime[n]=0;}
        }
        for(int n=0;n<builderSlots();n++)if(constructorJob[n]>=0){
          constructorTime[n]-=dt;
          if(constructorTime[n]<=0){parts[constructorJob[n]]++;madeDone++;constructorJob[n]=-1;constructorTime[n]=0;}
        }
        startJobs();
        if(tech[7]){
          autoSellTimer+=dt;
          if(autoSellTimer>=28){autoSellTimer%=28;
             for(int i=0;i<ORES;i++){int portion=(int)Math.max(0,Math.floor(raw[i]-marketReserve));if(portion>0)sell(0,i,portion);}
          }
        }
      }
    }
    private double autoSellTimer=0;
    public void advanceToNow(){long now=System.currentTimeMillis();long diff=now-lastMs;
      if(diff>0){double elapsed=Math.min(12*3600,diff/1000.);idleProduced=totalMined;advance(elapsed);idleProduced=Math.max(0,totalMined-idleProduced);timeOffline=elapsed;}
      lastMs=now;
    }
    private static JSONArray nums(double[] a){JSONArray j=new JSONArray();for(double x:a)j.put(x);return j;}
    private static JSONArray ints(int[] a){JSONArray j=new JSONArray();for(int x:a)j.put(x);return j;}
    private static JSONArray bools(boolean[] a){JSONArray j=new JSONArray();for(boolean x:a)j.put(x);return j;}
    private static void readD(JSONObject j,String name,double[] dst){JSONArray a=j.optJSONArray(name);if(a==null)return;for(int i=0;i<Math.min(dst.length,a.length());i++)dst[i]=Math.max(0,a.optDouble(i,dst[i]));}
    private static void readI(JSONObject j,String name,int[] dst){JSONArray a=j.optJSONArray(name);if(a==null)return;for(int i=0;i<Math.min(dst.length,a.length());i++)dst[i]=a.optInt(i,dst[i]);}
    private static void readB(JSONObject j,String name,boolean[] dst){JSONArray a=j.optJSONArray(name);if(a==null)return;for(int i=0;i<Math.min(dst.length,a.length());i++)dst[i]=a.optBoolean(i,dst[i]);}
    public void save(Context ctx){try{
      JSONObject j=new JSONObject();j.put("planet",planet);j.put("rank",rank);j.put("science",science);j.put("stars",stars);j.put("contractSequence",contractSequence);j.put("contractsDone",contractsDone);
      j.put("upgrades",upgrades);j.put("refinedDone",refinedDone);j.put("madeDone",madeDone);j.put("credits",credits);j.put("totalMined",totalMined);j.put("totalDelivered",totalDelivered);
      j.put("totalEarned",totalEarned);j.put("totalSold",totalSold);j.put("totalTime",totalTime);j.put("boost",speedBoostRemaining);j.put("lastMs",lastMs);
      j.put("marketReserve",marketReserve);j.put("productionMode",productionMode);j.put("selectedMine",selectedMine);j.put("upgradeAmount",upgradeAmount);j.put("tutorialStage",tutorialStage);
      j.put("missionStart",nums(missionStart));j.put("missionContractsStart",missionContractsStart);
      j.put("open",bools(open));j.put("tech",bools(tech));j.put("hired",bools(hired));j.put("drill",ints(drill));j.put("ship",ints(ship));j.put("cargo",ints(cargo));j.put("crewAssigned",ints(crewAssigned));
      j.put("refQueue",ints(refQueue));j.put("partQueue",ints(partQueue));j.put("plans",ints(plans));j.put("hopper",nums(hopper));j.put("freight",nums(freight));j.put("flight",nums(flight));
      j.put("raw",nums(raw));j.put("alloys",nums(alloys));j.put("parts",nums(parts));j.put("refineryJob",ints(refineryJob));j.put("constructorJob",ints(constructorJob));
      j.put("refineryTime",nums(refineryTime));j.put("constructorTime",nums(constructorTime));j.put("contractKind",ints(contractKind));j.put("contractResource",ints(contractResource));j.put("contractQty",nums(contractQty));j.put("contractReward",nums(contractReward));j.put("contractScience",ints(contractScience));j.put("autoSellTimer",autoSellTimer);
      ctx.getSharedPreferences("possminer_frontier_v2",Context.MODE_PRIVATE).edit().putString("save",j.toString()).apply();
    }catch(Exception ignored){}
    }
    public static FrontierGame load(Context ctx){FrontierGame g=new FrontierGame();String v=ctx.getSharedPreferences("possminer_frontier_v2",Context.MODE_PRIVATE).getString("save",null);if(v==null)return g;
      try{JSONObject j=new JSONObject(v);
        g.planet=Math.max(0,j.optInt("planet"));g.rank=Math.max(1,Math.min(21,j.optInt("rank",1)));g.science=Math.max(0,j.optInt("science"));g.stars=Math.max(0,j.optInt("stars"));
        g.contractSequence=Math.max(3,j.optInt("contractSequence",3));g.contractsDone=j.optInt("contractsDone");g.upgrades=j.optInt("upgrades");g.refinedDone=j.optInt("refinedDone");g.madeDone=j.optInt("madeDone");
        g.credits=Math.max(0,j.optDouble("credits",650));g.totalMined=Math.max(0,j.optDouble("totalMined"));g.totalDelivered=Math.max(0,j.optDouble("totalDelivered"));
        g.totalEarned=Math.max(0,j.optDouble("totalEarned"));g.totalSold=Math.max(0,j.optDouble("totalSold"));g.totalTime=Math.max(0,j.optDouble("totalTime"));g.speedBoostRemaining=Math.max(0,j.optDouble("boost"));g.lastMs=j.optLong("lastMs",System.currentTimeMillis());
        g.marketReserve=j.optInt("marketReserve");g.productionMode=j.optInt("productionMode");g.selectedMine=j.optInt("selectedMine");g.upgradeAmount=j.optInt("upgradeAmount",1);g.tutorialStage=j.optInt("tutorialStage");g.missionContractsStart=j.optInt("missionContractsStart");
        readD(j,"missionStart",g.missionStart);readB(j,"open",g.open);readB(j,"tech",g.tech);readB(j,"hired",g.hired);
        readI(j,"drill",g.drill);readI(j,"ship",g.ship);readI(j,"cargo",g.cargo);readI(j,"crewAssigned",g.crewAssigned);
        readI(j,"refQueue",g.refQueue);readI(j,"partQueue",g.partQueue);readI(j,"plans",g.plans);
        readD(j,"hopper",g.hopper);readD(j,"freight",g.freight);readD(j,"flight",g.flight);
        readD(j,"raw",g.raw);readD(j,"alloys",g.alloys);readD(j,"parts",g.parts);
        readI(j,"refineryJob",g.refineryJob);readI(j,"constructorJob",g.constructorJob);readD(j,"refineryTime",g.refineryTime);readD(j,"constructorTime",g.constructorTime);
        readI(j,"contractKind",g.contractKind);readI(j,"contractResource",g.contractResource);readD(j,"contractQty",g.contractQty);readD(j,"contractReward",g.contractReward);readI(j,"contractScience",g.contractScience);g.autoSellTimer=j.optDouble("autoSellTimer");
        g.open[0]=true;g.plans[0]=g.plans[1]=1;
        return g;
      }catch(Exception e){return new FrontierGame();}
    }
    public static String n(double v){if(Double.isNaN(v)||Double.isInfinite(v))return "?";double a=Math.abs(v);
      if(a>=1e12)return String.format(Locale.ITALY,"%.2fT",v/1e12);
      if(a>=1e9)return String.format(Locale.ITALY,"%.2fG",v/1e9);
      if(a>=1e6)return String.format(Locale.ITALY,"%.2fM",v/1e6);
      if(a>=10000)return String.format(Locale.ITALY,"%.1fk",v/1000);
      if(a>=100)return String.format(Locale.ITALY,"%,.0f",Math.floor(v));
      if(a>=10)return String.format(Locale.ITALY,"%.1f",v);
      return String.format(Locale.ITALY,"%.2f",v);
    }
}
