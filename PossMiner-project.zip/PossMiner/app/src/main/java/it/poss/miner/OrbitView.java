package it.poss.miner;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Custom-drawn illustration made specifically for PossMiner. No external sprites or textures. */
public final class OrbitView extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private float phase=0;
    private final float[] starX=new float[48],starY=new float[48],starR=new float[48];
    public OrbitView(Context c){
        super(c);
        java.util.Random r=new java.util.Random(1938821);
        for(int i=0;i<starX.length;i++){starX[i]=r.nextFloat();starY[i]=r.nextFloat();starR[i]=.35f+r.nextFloat()*.85f;}
        setLayerType(View.LAYER_TYPE_SOFTWARE,null);
    }
    public void animateFrame(){phase+=.025f;invalidate();}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        float w=getWidth(),h=getHeight();
        p.setShader(new LinearGradient(0,0,w,h,new int[]{0xFF0A1B30,0xFF132A42,0xFF091424},null, Shader.TileMode.CLAMP));
        canvas.drawRect(0,0,w,h,p);p.setShader(null);
        for(int i=0;i<starX.length;i++){
            p.setColor(i%4==0?0xFF6CCDD9:0xFFB6CDD4);
            p.setAlpha(80+i%3*40);
            canvas.drawCircle(starX[i]*w,starY[i]*h,starR[i]*getResources().getDisplayMetrics().density,p);
        }
        p.setAlpha(255);
        float cx=w*.52f,cy=h*.54f;
        float rad=Math.min(w*.29f,h*.47f);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1.5f,w*.003f));p.setColor(0x4A6EE5DA);
        canvas.save();canvas.rotate(-13,cx,cy);
        canvas.drawOval(cx-rad*1.52f,cy-rad*.48f,cx+rad*1.52f,cy+rad*.48f,p);
        p.setColor(0x384E8CA3);canvas.drawOval(cx-rad*1.77f,cy-rad*.68f,cx+rad*1.77f,cy+rad*.68f,p);
        canvas.restore();p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx-rad*.4f,cy-rad*.4f,rad*1.9f,new int[]{0xFF5B9FAF,0xFF2B607D,0xFF132840},null,Shader.TileMode.CLAMP));
        canvas.drawCircle(cx,cy,rad,p);p.setShader(null);
        canvas.save();
        Path clip=new Path();clip.addCircle(cx,cy,rad,Path.Direction.CW);canvas.clipPath(clip);
        p.setColor(0x4453CFCE);
        Path land=new Path();
        land.moveTo(cx-rad*1.1f,cy-rad*.3f);
        land.cubicTo(cx-rad*.45f,cy-rad*.83f,cx-rad*.12f,cy-rad*.2f,cx+rad*.35f,cy-rad*.5f);
        land.cubicTo(cx+rad*.95f,cy-rad*.95f,cx+rad*1.4f,cy-rad*.2f,cx+rad*1.2f,cy+rad*.2f);
        land.cubicTo(cx+rad*.4f,cy+rad*.14f,cx+rad*.5f,cy+rad*.7f,cx-rad*.4f,cy+rad*.5f);
        land.close();canvas.drawPath(land,p);
        p.setColor(0x3CAED6D9);canvas.drawOval(cx-rad*.9f,cy+rad*.4f,cx-rad*.25f,cy+rad*.9f,p);
        p.setColor(0x3D061629);canvas.drawOval(cx-rad*.18f,cy-rad*.2f,cx+rad*.25f,cy+rad*.1f,p);
        p.setColor(0x3C9AD4E1);
        canvas.drawCircle(cx-rad*.46f,cy-rad*.4f,rad*.12f,p);
        canvas.drawCircle(cx+rad*.49f,cy+rad*.46f,rad*.11f,p);
        canvas.restore();
        // Drones travelling around the planet
        for(int k=0;k<3;k++){
            double a=phase*(k%2==0?1:-.78f)+k*2.094;
            float x=cx+(float)Math.cos(a)*rad*1.51f;
            float y=cy+(float)Math.sin(a)*rad*.45f;
            p.setColor(k==0?0xFF35EACF:0xFFFFD58A);canvas.drawCircle(x,y,Math.max(4,w*.013f),p);
            p.setColor(0x5574F7F4);canvas.drawCircle(x,y,Math.max(8,w*.025f),p);
        }
        p.setColor(0xFFE4FAF9);p.setTypeface(android.graphics.Typeface.create("sans-serif-medium",1));
        p.setTextSize(Math.max(16,w*.047f));canvas.drawText("V E S P E R A",w*.055f,h*.13f,p);
        p.setColor(0xFF76AFBF);p.setTypeface(android.graphics.Typeface.DEFAULT);
        p.setTextSize(Math.max(11,w*.03f));canvas.drawText("SETTORE 07   //   SISTEMA AZUR",w*.055f,h*.205f,p);
        p.setColor(0xFF34E3CD);p.setTextSize(Math.max(10,w*.027f));
        canvas.drawText("MINIERE ATTIVE",w*.058f,h*.84f,p);
        p.setColor(0x8884A6B8);canvas.drawText("SCANSIONE IN CORSO",w*.62f,h*.84f,p);
    }
}
