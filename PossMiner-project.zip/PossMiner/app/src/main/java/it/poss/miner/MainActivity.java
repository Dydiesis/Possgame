package it.poss.miner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Original PossMiner Frontiera interface, designed for ordinary Android without online dependencies. */
public final class MainActivity extends Activity {
  private static final int BG=0xFF071222, PAN=0xFF11283F, PAN2=0xFF19364D;
  private static final int TEXT=0xFFF0FAFC, MUTED=0xFF98B1C2, AQUA=0xFF5CE6CF, SKY=0xFF88CCFF, AMBER=0xFFFBC378, RED=0xFFFF9DA8;
  private FrontierGame g; private int tab=0, tick=0;
  private LinearLayout root,header,content,nav;private ScrollView scroll;private TextView money,mini,rankLabel;
  private StarMapView map;
  private final Handler handler=new Handler(Looper.getMainLooper());
  private final Runnable updater=new Runnable(){@Override public void run(){
    if(g!=null){g.advanceToNow();updateHUD();if(map!=null)map.progress();if(++tick%3==0)render(false);if(tick%15==0)g.save(MainActivity.this);}
    handler.postDelayed(this,1000);
  }};
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    g=FrontierGame.load(this);g.advanceToNow();double idle=g.idleProduced;double dur=g.timeOffline;g.save(this);setup();render(true);
    if(dur>90&&idle>=1)new AlertDialog.Builder(this).setTitle("Le miniere hanno lavorato!")
       .setMessage("Durante "+FrontierGame.n(dur/60)+" minuti di assenza sono stati estratti "+FrontierGame.n(idle)+" minerali.\nProduzione offline fino a 12 ore, senza pubblicità.")
       .setPositiveButton("RITIRA",(d,w)->{}).show();
    handler.postDelayed(updater,1000);
  }
  @Override protected void onPause(){if(g!=null){g.advanceToNow();g.save(this);}super.onPause();}
  @Override protected void onDestroy(){handler.removeCallbacks(updater);super.onDestroy();}
  private int dp(float v){return Math.round(getResources().getDisplayMetrics().density*v);}
  private LinearLayout col(){LinearLayout a=new LinearLayout(this);a.setOrientation(LinearLayout.VERTICAL);return a;}
  private LinearLayout row(){LinearLayout a=new LinearLayout(this);a.setOrientation(LinearLayout.HORIZONTAL);a.setGravity(Gravity.CENTER_VERTICAL);return a;}
  private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);t.setIncludeFontPadding(true);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private GradientDrawable bg(int fill,float corner){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(corner));return d;}
  private GradientDrawable bordered(int fill,float corner,int stroke){GradientDrawable d=bg(fill,corner);d.setStroke(dp(1),stroke);return d;}
  private LinearLayout.LayoutParams m(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
  private TextView small(String s){return text(s,12,MUTED,false);}
  private TextView badge(String s,int color){TextView t=text(s,11,color,true);t.setPadding(dp(11),dp(7),dp(11),dp(7));t.setBackground(bg(0xFF183B46,16));return t;}
  private LinearLayout panel(){LinearLayout p=col();p.setPadding(dp(16),dp(16),dp(16),dp(16));p.setBackground(bordered(PAN,18,0xFF29485D));content.addView(p,m(-1,-2,14,7,14,10));return p;}
  private void spacer(LinearLayout p,int h){View v=new View(this);p.addView(v,m(1,h,0,0,0,0));}
  private void line(LinearLayout p){View v=new View(this);v.setBackgroundColor(0xFF2A455A);p.addView(v,m(-1,1,0,13,0,13));}
  private void para(LinearLayout p,String v){TextView t=small(v);t.setLineSpacing(dp(3),1);p.addView(t,m(-1,-2,0,5,0,2));}
  private void section(String h,String s){TextView title=text(h,22,TEXT,true);content.addView(title,m(-1,-2,18,18,14,2));if(s!=null&&!s.isEmpty()){TextView sub=small(s);sub.setLineSpacing(dp(2),1);content.addView(sub,m(-1,-2,18,3,16,10));}}
  private void stat(LinearLayout p,String left,String right){LinearLayout a=row();TextView l=small(left),r=text(right,13,TEXT,true);a.addView(l,new LinearLayout.LayoutParams(0,-2,1));a.addView(r);p.addView(a,m(-1,-2,0,3,0,3));}
  private void meter(LinearLayout p,double value,int color){double safe=Math.max(0,Math.min(1,value));LinearLayout bar=row();bar.setBackground(bg(0xFF2B3E55,7));
    if(safe>0.00001){View yes=new View(this);yes.setBackground(bg(color,7));bar.addView(yes,new LinearLayout.LayoutParams(0,-1,(float)safe));}
    if(safe<.99999){View no=new View(this);bar.addView(no,new LinearLayout.LayoutParams(0,-1,(float)(1-safe)));}
    p.addView(bar,m(-1,7,0,7,0,7));
  }
  private TextView button(String label,boolean active,boolean standout,Runnable action){TextView b=text(label,12,active?(standout?BG:TEXT):0xFF7890A2,true);b.setGravity(Gravity.CENTER);b.setMinHeight(dp(45));b.setPadding(dp(6),dp(8),dp(6),dp(8));
    b.setBackground(bordered(active?(standout?AQUA:PAN2):0xFF12283B,12,active?(standout?0xFF2FEBC3:0xFF2E4A62):0xFF173143));
    b.setEnabled(active);if(active)b.setOnClickListener(v->{g.advanceToNow();action.run();g.save(this);updateHUD();render(false);});return b;}
  private void action(LinearLayout p,String label,boolean enabled,boolean primary,Runnable handler){p.addView(button(label,enabled,primary,handler),m(-1,-2,0,10,0,0));}
  private void pair(LinearLayout p,String labelA,boolean ena,Runnable ra,String labelB,boolean enb,Runnable rb){LinearLayout r=row();TextView a=button(labelA,ena,false,ra),b=button(labelB,enb,false,rb);
    LinearLayout.LayoutParams p1=new LinearLayout.LayoutParams(0,-2,1),p2=new LinearLayout.LayoutParams(0,-2,1);p1.setMargins(0,0,dp(5),0);p2.setMargins(dp(5),0,0,0);
    r.addView(a,p1);r.addView(b,p2);p.addView(r,m(-1,-2,0,9,0,0));}
  private void notify(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
  private void setup(){root=col();root.setBackgroundColor(BG);setContentView(root);
    header=col();header.setPadding(dp(17),dp(12),dp(17),dp(12));header.setBackgroundColor(0xFF0B1D31);root.addView(header,m(-1,-2,0,0,0,0));
    LinearLayout top=row();LinearLayout left=col();left.addView(text("◈  POSS MINER",22,AQUA,true));left.addView(text("FRONTIERA INDUSTRIALE  •  2.0",10,MUTED,true));top.addView(left,new LinearLayout.LayoutParams(0,-2,1));
    LinearLayout right=col();right.setGravity(Gravity.RIGHT);money=text("",20,AMBER,true);money.setGravity(Gravity.RIGHT);mini=text("",11,MUTED,false);mini.setGravity(Gravity.RIGHT);right.addView(money);right.addView(mini);top.addView(right);header.addView(top);
    LinearLayout lower=row();rankLabel=text("",11,SKY,true);lower.addView(rankLabel,new LinearLayout.LayoutParams(0,-2,1));
    TextView help=text("ⓘ  GUIDA",11,AQUA,true);help.setOnClickListener(v->guide());lower.addView(help);
    header.addView(lower,m(-1,-2,1,13,1,0));
    View separator=new View(this);separator.setBackgroundColor(0xFF26435A);root.addView(separator,m(-1,1,0,0,0,0));
    scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);content=col();content.setPadding(0,dp(4),0,dp(20));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    nav=row();nav.setBackgroundColor(0xFF0B2034);nav.setPadding(dp(3),dp(7),dp(3),dp(7));root.addView(nav,m(-1,-2,0,0,0,0));updateHUD();
  }
  private void updateHUD(){if(g==null||money==null)return;money.setText("◈ "+FrontierGame.n(g.credits)+" CR");
    mini.setText("⚗ "+g.science+" SCI    ✦ "+g.stars+" ASTRA");
    rankLabel.setText("RANGO "+g.rank+"/20   •   PIANETA "+(g.planet+1)+"   •   +"+FrontierGame.n(g.ratePerMinute())+" MIN/MIN");
  }
  private void nav(){nav.removeAllViews();String[] tags={"PIANETA","PRODUZ.","RICERCA","EQUIPAG.","OBIETTIVI"};String[] ico={"◉","⚙","⬡","✧","★"};
    for(int i=0;i<tags.length;i++){final int index=i;LinearLayout cell=col();cell.setGravity(Gravity.CENTER);cell.setPadding(dp(1),dp(7),dp(1),dp(7));cell.setBackground(bg(tab==i?0xFF19463F:0xFF0B2034,10));
      TextView ic=text(ico[i],19,tab==i?AQUA:MUTED,true),label=text(tags[i],9,tab==i?AQUA:MUTED,true);ic.setGravity(Gravity.CENTER);label.setGravity(Gravity.CENTER);
      cell.addView(ic);cell.addView(label);nav.addView(cell,new LinearLayout.LayoutParams(0,dp(58),1));cell.setOnClickListener(v->{tab=index;render(true);});}
  }
  private void render(boolean reset){if(content==null)return;int y=reset?0:scroll.getScrollY();map=null;content.removeAllViews();nav();
    switch(tab){case 0:planet();break;case 1:factory();break;case 2:research();break;case 3:crew();break;default:objectives();}
    if(reset)scroll.post(()->scroll.scrollTo(0,0));else scroll.post(()->scroll.scrollTo(0,y));
  }
  private void heroBadges(){LinearLayout t=row();t.setPadding(dp(14),dp(3),dp(10),dp(7));t.addView(badge("● "+g.opened()+"/18 MINIERE",AQUA),m(-2,-2,0,1,8,0));t.addView(badge("◈ "+FrontierGame.n(g.warehouseTotal())+" IN BASE",AMBER));content.addView(t);}
  private void planet(){
    map=new StarMapView(this,g);map.setListener(i->{g.selectedMine=i;render(false);notify(FrontierGame.ZONES[i]);});
    content.addView(map,m(-1,238,13,9,13,7));heroBadges();
    LinearLayout summary=panel();summary.addView(text("Il tuo impero minerario",18,TEXT,true));para(summary,"Le trivelle riempiono il SILO sul posto. Le navette effettuano viaggi con carico limitato e consegnano i minerali al MAGAZZINO centrale.");
    stat(summary,"Minerali estratti",FrontierGame.n(g.totalMined));stat(summary,"Produzione stimata",FrontierGame.n(g.ratePerMinute())+" unità/min");
    stat(summary,"Valore totale magazzino","◈ "+FrontierGame.n(g.inventoryWorth()));
    if(g.speedBoostRemaining>0)summary.addView(badge("TURBO ATTIVO: "+FrontierGame.n(g.speedBoostRemaining)+" s",AMBER),m(-2,-2,0,10,0,0));
    section("Controllo giacimenti","Tocca i punti luminosi sul pianeta o scegli un sito. I tre potenziamenti influenzano fasi diverse del trasporto.");
    mineDetail(g.selectedMine);
    LinearLayout list=panel();list.addView(text("MAPPA DEI SITI",14,SKY,true));
    for(int i=0;i<FrontierGame.DEPOSITS;i++){if(!g.open[i]&&i>g.opened()+2)continue;final int id=i;
      String label=(g.open[i]?"● ":"○ ")+(i+1)+"  "+FrontierGame.ZONES[i]+(g.open[i]?"  ·  "+FrontierGame.ORE[g.oreOf(i)]:"  ·  ◈ "+FrontierGame.n(g.openCost(i)));
      if(i==g.selectedMine)label="➤ "+label;
      TextView item=button(label,true,false,()->{g.selectedMine=id;render(false);});
      item.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);list.addView(item,m(-1,-2,0,6,0,0));
    }
  }
  private void mineDetail(int i){
    if(i<0||i>=FrontierGame.DEPOSITS){g.selectedMine=0;i=0;}final int id=i;
    LinearLayout p=panel();LinearLayout r=row();TextView symbol=text(FrontierGame.ORE_SYMBOL[g.oreOf(i)],17,FrontierGame.ORE_COLOR[g.oreOf(i)],true);symbol.setGravity(Gravity.CENTER);symbol.setBackground(bg(0xFF1C3A4A,12));r.addView(symbol,m(52,50,0,0,12,0));
    LinearLayout labels=col();labels.addView(text(FrontierGame.ZONES[i].toUpperCase(),16,TEXT,true));
    labels.addView(text(FrontierGame.ORE[g.oreOf(i)]+"  ·  "+FrontierGame.n(g.oreValue(g.oreOf(i)))+" CR/pezzo",11,MUTED,false));r.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
    r.addView(badge(g.open[i]?"ATTIVA":"BLOCCATA",g.open[i]?AQUA:AMBER));p.addView(r);
    if(!g.open[i]){para(p,"Sblocca questa zona per attivare un nuovo tipo di produzione e nuovi materiali da trasformare.");
      action(p,"APRI IL GIACIMENTO   •   ◈ "+FrontierGame.n(g.openCost(i)),g.credits>=g.openCost(i),true,()->{
        if(g.buyDeposit(id))notify("Nuovo sito operativo!");else notify("Non hai abbastanza crediti");});return;}
    line(p);stat(p,"ESTRAZIONE",FrontierGame.n(g.rate(i))+" minerali/s");
    stat(p,"NAVETTA",FrontierGame.n(g.carry(i))+" pezzi/viaggio");
    stat(p,"DURATA VIAGGIO",FrontierGame.n(g.tripDuration(i))+" s");
    double fraction=g.hopper[i]/g.cap(i);
    p.addView(text("SILO LOCALE  "+FrontierGame.n(g.hopper[i])+" / "+FrontierGame.n(g.cap(i)),12,SKY,true),m(-1,-2,0,10,0,0));meter(p,fraction,SKY);
    stat(p,"Nella navetta in viaggio",FrontierGame.n(g.freight[i]));
    stat(p,"In magazzino centrale",FrontierGame.n(g.raw[g.oreOf(i)]));
    line(p);
    LinearLayout picker=row();picker.addView(small("ACQUISTA"),new LinearLayout.LayoutParams(0,-2,1));
    for(int count:new int[]{1,10,999}){final int quantity=count;TextView choice=button(count==999?"MAX":"×"+count,true,false,()->{g.upgradeAmount=quantity;});
      if(g.upgradeAmount==quantity)choice.setBackground(bordered(0xFF2A6157,8,AQUA));
      picker.addView(choice,m(58,36,3,0,0,0));}p.addView(picker);
    String[] upname={"TRAPANO","VELOCITÀ","CARICO"};int[] lv={g.drill[i],g.ship[i],g.cargo[i]};
    for(int kind=0;kind<3;kind++){final int k=kind;
      double cost=g.price(i,kind);
      action(p,upname[k]+" L"+lv[k]+"    •    ◈ "+FrontierGame.n(cost)+"/livello",g.credits>=cost,false,()->{
         int how=g.buyUpgrade(id,k,g.upgradeAmount);notify(how>0?"Potenziamenti acquistati: "+how:"Non puoi permetterti il potenziamento");});
    }
  }
  private void factory(){section("Catena industriale","Le risorse hanno tempi di produzione, code e ricette: per i componenti complessi devi prima preparare le materie intermedie.");
    LinearLayout seg=row();String[] names={"MAGAZZINO","FONDERIA","CANTIERE"};
    for(int i=0;i<3;i++){final int index=i;TextView b=button(names[i],true,false,()->{g.productionMode=index;render(false);});if(i==g.productionMode)b.setBackground(bordered(0xFF24594D,12,AQUA));seg.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));}
    content.addView(seg,m(-1,-2,14,8,14,8));
    if(g.productionMode==0)warehouse();else if(g.productionMode==1)refinery();else constructor();
  }
  private void warehouse(){LinearLayout info=panel();info.addView(text("MAGAZZINO CENTRALE",17,TEXT,true));
    para(info,"Qui arrivano soltanto le risorse effettivamente trasportate dalle navette. Puoi conservarle per le ricette, venderle o consegnarle ai contratti.");
    stat(info,"Materie prime",FrontierGame.n(g.warehouseTotal()));stat(info,"Valore stimato",FrontierGame.n(g.inventoryWorth())+" CR");
    action(info,"VENDI TUTTI I MINERALI GREZZI",g.warehouseTotal()>=1,false,()->{g.sellEverythingRaw();notify("Materie prime vendute");});
    for(int i=0;i<FrontierGame.ORES;i++){
      if(g.raw[i]<1&&!existsOre(i))continue;final int id=i;LinearLayout p=panel();LinearLayout r=row();
      TextView icon=text(FrontierGame.ORE_SYMBOL[i],18,FrontierGame.ORE_COLOR[i],true);icon.setBackground(bg(0xFF1C3A4A,9));icon.setGravity(Gravity.CENTER);r.addView(icon,m(46,46,0,0,12,0));
      LinearLayout t=col();t.addView(text(FrontierGame.ORE[i],17,TEXT,true));t.addView(small("Valore  "+FrontierGame.n(g.oreValue(i))+" CR/unità"));r.addView(t,new LinearLayout.LayoutParams(0,-2,1));r.addView(text(FrontierGame.n(g.raw[i]),17,AMBER,true));p.addView(r);
      pair(p,"VENDI 10",g.raw[i]>=1,()->{g.sell(0,id,10);notify("Vendita eseguita");},"VENDI TUTTO",g.raw[i]>=1,()->{g.sell(0,id,999999);notify("Vendita eseguita");});
    }
    LinearLayout market=panel();market.addView(text("COMMERCIO INTELLIGENTE",16,TEXT,true));
    para(market,"La tecnologia Mercato automatico vende solo i minerali oltre la riserva configurata. Tieni delle scorte per la produzione.");
    stat(market,"Vendita automatica",g.tech[7]?"ATTIVA":"DA RICERCARE");
    pair(market,"RISERVA 0",true,()->g.marketReserve=0,"RISERVA 100",true,()->g.marketReserve=100);
    stat(market,"Riserva per materiale",g.marketReserve+" unità");
  }
  private boolean existsOre(int id){for(int i=0;i<FrontierGame.DEPOSITS;i++)if(g.open[i]&&(g.oreOf(i)==id||g.secondOre(i)==id))return true;return id<3;}
  private void refinery(){LinearLayout top=panel();top.addView(text("FONDERIA AUTOMATICA",17,TEXT,true));
    para(top,"Ogni linea lavora una ricetta alla volta. La coda riparte automaticamente quando ci sono i materiali richiesti.");
    stat(top,"Linee di raffinazione",g.refinerySlots()+" / 3");
    for(int slot=0;slot<g.refinerySlots();slot++){
      int job=g.refineryJob[slot];stat(top,"Linea "+(slot+1),job<0?"LIBERA":FrontierGame.ALLOY[job]+" • "+FrontierGame.n(g.refineryTime[slot])+" s");
    }
    action(top,"VENDI TUTTE LE LEGHE",true,false,()->{g.sellEverythingAlloys();notify("Leghe vendute");});
    for(int i=0;i<FrontierGame.ALLOYS;i++){
      final int id=i;LinearLayout p=panel();
      p.addView(text(FrontierGame.ALLOY[i].toUpperCase(),16,TEXT,true));
      para(p,"Ricetta: "+g.alloyCost(i)+" × "+FrontierGame.ORE[i]+"   •   "+FrontierGame.n(FrontierGame.ALLOY_TIME[i]/g.refinerySpeed())+" s per lotto");
      stat(p,"Materiale grezzo",FrontierGame.n(g.raw[i]));stat(p,"Leghe pronte",FrontierGame.n(g.alloys[i]));
      stat(p,"In coda",g.refQueue[i]+" lavori");
      pair(p,"PRODUCI ×1",true,()->g.queueRefining(id,1),"PRODUCI ×5",true,()->g.queueRefining(id,5));
      pair(p,"VENDI LEGHE",g.alloys[i]>=1,()->{g.sell(1,id,999999);notify("Leghe vendute");},"ANNULLA CODA",g.refQueue[i]>0,()->g.cancelQueue(true,id));
      if(i>=6&&g.opened()<i-1)break;
    }
  }
  private void constructor(){LinearLayout info=panel();info.addView(text("CANTIERE DI ASSEMBLAGGIO",17,TEXT,true));
    para(info,"Costruisci dispositivi usando leghe e altri componenti. I progetti più avanzati richiedono più passaggi di lavorazione.");
    stat(info,"Linee di montaggio",g.builderSlots()+" / 3");
    for(int slot=0;slot<g.builderSlots();slot++){
      int job=g.constructorJob[slot];stat(info,"Linea "+(slot+1),job<0?"LIBERA":FrontierGame.PART[job]+" • "+FrontierGame.n(g.constructorTime[slot])+" s");
    }
    for(int i=0;i<FrontierGame.PARTS;i++){
      final int id=i;LinearLayout p=panel();p.addView(text("▣  "+FrontierGame.PART[i].toUpperCase(),16,i<2?AQUA:TEXT,true));
      stat(p,"Magazzino",FrontierGame.n(g.parts[i]));stat(p,"Valore di vendita",FrontierGame.n(g.partValue(i))+" CR");
      if(g.plans[i]==0){para(p,"Progetto non ancora acquisito. Sblocca la ricetta per costruire questo componente.");
        double cost=850*Math.pow(3.7,i)*g.planetMultiplier();
        action(p,"ACQUISTA PROGETTO • ◈ "+FrontierGame.n(cost),g.credits>=cost,true,()->{if(g.buyBlueprint(id))notify("Progetto sbloccato!");});
        if(i>=6)break;continue;}
      StringBuilder rec=new StringBuilder("RICHIEDE: ");int[] a=g.partAlloyNeeds(i),b=g.partComponentNeeds(i);
      for(int k=0;k<a.length;k++)if(a[k]>0)rec.append(a[k]).append(" ").append(FrontierGame.ALLOY[k]).append("; ");
      for(int k=0;k<b.length;k++)if(b[k]>0)rec.append(b[k]).append(" ").append(FrontierGame.PART[k]).append("; ");
      para(p,rec.toString());para(p,"Tempo: "+FrontierGame.n(FrontierGame.PART_TIME[i]/g.constructorSpeed())+" s • In coda: "+g.partQueue[i]);
      pair(p,"COSTRUISCI ×1",true,()->g.queueCrafting(id,1),"COSTRUISCI ×5",true,()->g.queueCrafting(id,5));
      pair(p,"VENDI",g.parts[i]>=1,()->{g.sell(2,id,999999);notify("Componente venduto");},"ANNULLA CODA",g.partQueue[i]>0,()->g.cancelQueue(false,id));
    }
  }
  private void research(){section("Laboratorio scientifico","Ricerca 14 tecnologie indipendenti. La scienza si ottiene con ranghi e contratti; niente premi legati a spot pubblicitari.");
    LinearLayout overview=panel();overview.addView(text("CENTRO DI RICERCA",18,TEXT,true));
    stat(overview,"Punti scienza",g.science+" SCI");stat(overview,"Tecnologie acquisite",g.techCount()+" / "+FrontierGame.TECHS);
    para(overview,"Le ricerche tecnologiche si riavviano a ogni nuovo pianeta: equipaggio e stelle restano permanenti.");
    for(int i=0;i<FrontierGame.TECHS;i++){
      final int id=i;LinearLayout p=panel();
      LinearLayout row=row();TextView title=text((i+1)+"  "+FrontierGame.TECH_NAMES[i].toUpperCase(),14,TEXT,true);row.addView(title,new LinearLayout.LayoutParams(0,-2,1));row.addView(badge(g.tech[i]?"ATTIVA":"PROGETTO",g.tech[i]?AQUA:MUTED));p.addView(row);
      para(p,FrontierGame.TECH_DESC[i]);
      if(g.tech[i])continue;
      double cost=FrontierGame.TECH_CREDITS[i]*g.planetMultiplier();int req=FrontierGame.TECH_REQUIRES[i];
      if(req>=0&&!g.tech[req])para(p,"PREREQUISITO: "+FrontierGame.TECH_NAMES[req]);
      action(p,"RICERCA • ◈ "+FrontierGame.n(cost)+" + "+FrontierGame.TECH_SCIENCE[i]+" SCI",g.credits>=cost&&g.science>=FrontierGame.TECH_SCIENCE[i]&&(req<0||g.tech[req]),true,()->{
        if(g.buyTech(id))notify("Tecnologia sbloccata!");});
    }
  }
  private void crew(){section("Equipaggio permanente","Recluta specialisti con le stelle guadagnate nei ranghi e nei contratti. Restano a bordo quando raggiungi un nuovo pianeta.");
    LinearLayout summary=panel();summary.addView(text("QUARTIER GENERALE",17,TEXT,true));
    stat(summary,"Specialisti disponibili",g.hiredCount()+" / 8");stat(summary,"Stelle disponibili",g.stars+" ASTRA");
    para(summary,"Le prime tre figure possono essere assegnate a un giacimento a scelta. Le altre potenziano l'intera colonia.");
    for(int i=0;i<FrontierGame.CREW;i++){final int id=i;LinearLayout p=panel();
      LinearLayout head=row();TextView avatar=text(FrontierGame.CREW_NAME[i].substring(0,1),23,AMBER,true);avatar.setBackground(bg(0xFF1E4453,14));avatar.setGravity(Gravity.CENTER);head.addView(avatar,m(47,47,0,0,12,0));
      LinearLayout names=col();names.addView(text(FrontierGame.CREW_NAME[i].toUpperCase(),16,TEXT,true));names.addView(small(FrontierGame.CREW_ROLE[i]));head.addView(names,new LinearLayout.LayoutParams(0,-2,1));
      head.addView(badge(g.hired[i]?"A BORDO":"NON ASSUNTO",g.hired[i]?AQUA:AMBER));p.addView(head);
      para(p,FrontierGame.CREW_BONUS[i]);
      if(!g.hired[i])action(p,"RECLUTA • ✦ "+FrontierGame.CREW_PRICE[i]+" STELLE",g.stars>=FrontierGame.CREW_PRICE[i],true,()->{
        if(g.buyCrew(id))notify("Benvenuto a bordo, "+FrontierGame.CREW_NAME[id]);});
      else if(i<3){int index=g.crewAssigned[i];
        action(p,"ASSEGNA A UN SITO • "+(index<0?"NESSUNO":FrontierGame.ZONES[index]),true,false,()->assignDialog(id));
      }else p.addView(badge("BONUS GLOBALE ATTIVO",AQUA),m(-2,-2,0,8,0,0));
    }
  }
  private void assignDialog(int id){java.util.ArrayList<String> names=new java.util.ArrayList<>();java.util.ArrayList<Integer> ids=new java.util.ArrayList<>();
    names.add("Rimuovi assegnazione");ids.add(-1);
    for(int i=0;i<FrontierGame.DEPOSITS;i++)if(g.open[i]){names.add(FrontierGame.ZONES[i]);ids.add(i);}
    new AlertDialog.Builder(this).setTitle("Assegna "+FrontierGame.CREW_NAME[id]).setItems(names.toArray(new String[0]),(dialog,which)->{
      g.assignCrew(id,ids.get(which));g.save(this);render(false);
    }).show();
  }
  private void objectives(){section("Registro di missione","20 ranghi per pianeta, contratti ripetibili e trasferimenti fra mondi. Una progressione molto più lunga della vecchia versione.");
    LinearLayout rank=panel();rank.addView(badge("RANGO "+g.rank+"   •   PIANETA "+(g.planet+1),AQUA),m(-2,-2,0,0,0,12));
    if(g.rank<=20){rank.addView(text(FrontierGame.RANK_DESCRIPTIONS[g.rank-1],17,TEXT,true));
      double a=g.missionProgress(),b=g.missionTarget();stat(rank,"PROGRESSO",FrontierGame.n(Math.min(a,b))+" / "+FrontierGame.n(b));
      meter(rank,b>0?Math.min(1,a/b):0,AQUA);para(rank,"Ricompensa: crediti, ricerca scientifica e stelle permanenti.");
      action(rank,g.canClaimRank()?"RITIRA IL PREMIO E AVANZA":"OBIETTIVO NON ANCORA COMPLETO",g.canClaimRank(),true,()->{
        if(g.claimRank())notify("Nuovo rango! Ora sei al livello "+g.rank);});
    }else{
      rank.addView(text("SISTEMA COMPLETATO",19,AMBER,true));para(rank,"Hai completato 20 ranghi. Puoi trasferire la colonia verso un nuovo pianeta, con moltiplicatori superiori e un'altra lunga serie di obiettivi.");
      action(rank,"VIAGGIA VERSO IL PIANETA "+(g.planet+2),true,true,()->travelConfirmation());
    }
    LinearLayout roadmap=panel();roadmap.addView(text("PROSSIME TAPPE",16,TEXT,true));for(int i=g.rank;i<Math.min(20,g.rank+3);i++){
      stat(roadmap,"Rango "+(i+1),FrontierGame.RANK_DESCRIPTIONS[i]);
    }
    section("Contratti commerciali","Consegna scorte, leghe e componenti per ottenere crediti e punti scienza. Puoi sostituire un contratto usando 1 SCI.");
    for(int n=0;n<3;n++){
      final int slot=n;LinearLayout p=panel();p.addView(text("CONTRATTO #"+(n+1),15,AQUA,true));
      para(p,"Richiesta: "+FrontierGame.n(g.contractQty[n])+" × "+g.contractLabel(n));
      stat(p,"Scorte disponibili",FrontierGame.n(g.contractHave(n)));
      meter(p,Math.min(1,g.contractHave(n)/g.contractQty[n]),SKY);
      stat(p,"Ricompensa crediti","◈ "+FrontierGame.n(g.contractReward[n]));stat(p,"Ricompensa scienza","✧ "+g.contractScience[n]+" SCI");
      pair(p,"CONSEGNA",g.contractHave(n)>=g.contractQty[n],()->{
        if(g.deliverContract(slot))notify("Contratto completato!");},"CAMBIA • 1 SCI",g.science>=1,()->{g.refreshContract(slot);});
    }
    LinearLayout extra=panel();extra.addView(text("ARCHIVIO DELLA COLONIA",16,TEXT,true));
    stat(extra,"Pianeti esplorati",g.planet+1+"");stat(extra,"Giacimenti attivi",g.opened()+" / "+FrontierGame.DEPOSITS);
    stat(extra,"Minerali estratti",FrontierGame.n(g.totalMined));stat(extra,"Minerali trasportati",FrontierGame.n(g.totalDelivered));
    stat(extra,"Lotti raffinati",FrontierGame.n(g.refinedDone));stat(extra,"Componenti costruiti",FrontierGame.n(g.madeDone));
    stat(extra,"Contratti completati",g.contractsDone+"");stat(extra,"Ricavi totali",FrontierGame.n(g.totalEarned));
    stat(extra,"Tempo simulato",FrontierGame.n(g.totalTime/3600)+" ore");
    action(extra,"TURBO 10 MINUTI • ✦ 2 STELLE",g.stars>=2&&g.speedBoostRemaining<=0,false,()->{
      if(g.startBoost())notify("Estrazione raddoppiata per 10 minuti");});
    action(extra,"COME SI GIOCA",true,false,this::guide);
  }
  private void travelConfirmation(){new AlertDialog.Builder(this).setTitle("Viaggio interplanetario")
    .setMessage("Inizi una nuova colonia con economia più ricca. Miniere, scorte, ricerca e rango ripartono da zero. EQUIPAGGIO, STELLE e un bonus permanente restano tuoi. Partire?")
    .setNegativeButton("RIMANI",(d,w)->{}).setPositiveButton("PARTI",(d,w)->{
      if(g.nextPlanet()){g.save(this);tab=0;render(true);notify("Benvenuto su "+g.planetName());}
    }).show();}
  private void guide(){new AlertDialog.Builder(this).setTitle("PossMiner • Guida rapida")
    .setMessage("1. PIANETA: apri siti ed espandi trivelle, velocità e carico. Ogni navetta richiede tempo per consegnare i minerali.\n\n"+
     "2. MAGAZZINO: riceve i materiali arrivati alla base; puoi venderli o conservarli. Il SILO è invece il deposito vicino alla miniera.\n\n"+
     "3. FONDERIA: trasforma minerali in leghe con tempi reali e code di lavoro.\n\n"+
     "4. CANTIERE: usa leghe e componenti per costruire dispositivi sempre più complessi.\n\n"+
     "5. RICERCA ed EQUIPAGGIO: sblocca miglioramenti scientifici e professionisti permanenti.\n\n"+
     "6. OBIETTIVI: supera 20 ranghi, completa contratti e trasferisciti su nuovi pianeti.\n\n"+
     "Nessuna pubblicità, connessione, acquisto o pagamento necessario. Le miniere lavorano offline fino a 12 ore.")
    .setPositiveButton("CAPITO",(d,w)->{}).show();}
}
