package it.poss.miner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity {
    private static final int BG=0xFF07101E, SURFACE=0xFF102137, SURFACE2=0xFF162B42;
    private static final int WHITE=0xFFE8F9FC, MUTED=0xFF90AABA, ACCENT=0xFF34E3CD, GOLD=0xFFFFC36A, BLUE=0xFF83CAFB;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private GameState game;
    private int tab=0;
    private LinearLayout shell, cards, nav;
    private ScrollView scroll;
    private TextView creditsLabel, throughputLabel;
    private OrbitView orbit;
    private int frames=0;
    private final Runnable loop=new Runnable(){@Override public void run(){
        if(game!=null){
            game.advanceToNow();frames++;
            updateHud();
            if(orbit!=null)orbit.animateFrame();
            if(frames%3==0)render(false);
            if(frames%20==0)game.save(MainActivity.this);
        }
        handler.postDelayed(this,1000);
    }};

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        game=GameState.load(this);
        game.advanceToNow();game.save(this);
        makeLayout();render(true);
        if(game.offlineProduction>12)Toast.makeText(this,"Durante l'assenza: +"+GameState.num(game.offlineProduction)+" minerali estratti",Toast.LENGTH_LONG).show();
        handler.postDelayed(loop,1000);
    }
    @Override protected void onPause(){if(game!=null){game.advanceToNow();game.save(this);}super.onPause();}
    @Override protected void onDestroy(){handler.removeCallbacks(loop);super.onDestroy();}
    @Override public void onBackPressed(){if(tab!=0){switchTab(0);}else super.onBackPressed();}

    private int dp(float dp){return (int)(dp*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable shapeStroke(int color,int stroke,int radius){GradientDrawable d=shape(color,radius);d.setStroke(dp(1),stroke);return d;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView txt(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));
        t.setIncludeFontPadding(true);return t;
    }
    private LinearLayout.LayoutParams margin(int w,int h,int left,int top,int right,int bottom){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));
        p.setMargins(dp(left),dp(top),dp(right),dp(bottom));return p;
    }
    private TextView pill(String text,int fg,int bg){TextView t=txt(text,10,fg,true);t.setPadding(dp(10),dp(6),dp(10),dp(6));t.setBackground(shape(bg,16));t.setGravity(Gravity.CENTER);return t;}
    private LinearLayout panel(){
        LinearLayout l=col();l.setPadding(dp(14),dp(15),dp(14),dp(14));l.setBackground(shapeStroke(SURFACE,0xFF20394F,16));
        cards.addView(l,margin(-1,-2,14,0,14,12));return l;
    }
    private TextView title(String str){return txt(str,20,WHITE,true);}
    private void sub(LinearLayout parent,String text){TextView t=txt(text,12,MUTED,false);parent.addView(t,margin(-1,-2,0,5,0,0));}
    private void line(LinearLayout container){View v=new View(this);v.setBackgroundColor(0xFF294056);container.addView(v,margin(-1,1,0,12,0,12));}
    private Button button(String label,boolean active,boolean highlight,Runnable callback){
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(12);
        b.setSingleLine(false);b.setGravity(Gravity.CENTER);b.setMinimumHeight(0);b.setMinHeight(0);b.setPadding(dp(6),dp(7),dp(6),dp(7));
        b.setTextColor(active?(highlight?BG:WHITE):0xFF657A8B);
        b.setBackground(shape(active?(highlight?ACCENT:SURFACE2):0xFF142235,10));
        b.setEnabled(active);
        if(active)b.setOnClickListener(v->{callback.run();game.save(this);updateHud();render(false);});
        return b;
    }
    private void actionLine(LinearLayout parent,String name,boolean enabled,boolean highlight,Runnable action){
        parent.addView(button(name,enabled,highlight,action),margin(-1,43,0,10,0,0));
    }
    private void dualButtons(LinearLayout parent,String a,boolean aEnabled,Runnable aAction,String b,boolean bEnabled,Runnable bAction){
        LinearLayout l=row();LinearLayout.LayoutParams left=margin(0,44,0,10,5,0);left.weight=1;
        LinearLayout.LayoutParams right=margin(0,44,5,10,0,0);right.weight=1;
        l.addView(button(a,aEnabled,false,aAction),left);l.addView(button(b,bEnabled,false,bAction),right);
        parent.addView(l,margin(-1,-2,0,0,0,0));
    }
    private void sectionHeading(String heading,String hint){
        LinearLayout l=col();l.addView(title(heading));if(hint!=null)sub(l,hint);
        cards.addView(l,margin(-1,-2,18,14,18,16));
    }
    private void toast(String t){Toast.makeText(this,t,Toast.LENGTH_SHORT).show();}
    private void successful(boolean ok){if(!ok)toast("Crediti insufficienti");}

    private void makeLayout(){
        shell=col();shell.setBackgroundColor(BG);setContentView(shell);
        LinearLayout header=row();header.setPadding(dp(16),dp(15),dp(16),dp(12));
        LinearLayout name=col();
        name.addView(txt("◆  POSSMINER",21,ACCENT,true));
        name.addView(txt("FRONTIERA MINERARIA",10,MUTED,true));
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,-2,1);header.addView(name,np);
        LinearLayout numbers=col();numbers.setGravity(Gravity.END);
        creditsLabel=txt("◈  240 CR",19,GOLD,true);creditsLabel.setGravity(Gravity.RIGHT);
        throughputLabel=txt("+0/min",11,MUTED,false);throughputLabel.setGravity(Gravity.RIGHT);
        numbers.addView(creditsLabel);numbers.addView(throughputLabel);
        header.addView(numbers,margin(-2,-2,10,0,0,0));
        shell.addView(header,margin(-1,-2,0,0,0,0));
        View divider=new View(this);divider.setBackgroundColor(0xFF203547);shell.addView(divider,margin(-1,1,0,0,0,0));
        scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);
        cards=col();cards.setPadding(0,dp(4),0,dp(14));scroll.addView(cards);
        shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setBackgroundColor(0xFF0A1B2D);nav.setPadding(dp(4),dp(8),dp(4),dp(8));
        shell.addView(nav,margin(-1,-2,0,0,0,0));
        updateHud();
    }
    private void updateHud(){
        if(creditsLabel==null)return;
        creditsLabel.setText("◈  "+GameState.num(game.credits)+" CR");
        double sum=0;for(int i=0;i<GameState.N;i++)if(game.unlocked[i])sum+=Math.min(game.rate(i),game.transit(i))*60;
        throughputLabel.setText("+"+GameState.num(sum)+" minerali/min");
    }
    private void switchTab(int next){tab=next;render(true);}
    private void drawNav(){
        nav.removeAllViews();
        String[] labels={"PIANETA", "FONDERIA", "OFFICINA", "MISSIONI"};
        String[] symbols={"◉", "⬡", "✦", "★"};
        for(int i=0;i<labels.length;i++){
            final int id=i;
            LinearLayout box=col();box.setGravity(Gravity.CENTER);box.setPadding(dp(1),dp(7),dp(1),dp(8));
            box.setBackground(shape(i==tab?0xFF194039:0xFF0A1B2D,10));
            TextView ic=txt(symbols[i],19,i==tab?ACCENT:MUTED,true);ic.setGravity(Gravity.CENTER);
            TextView tx=txt(labels[i],9,i==tab?ACCENT:MUTED,true);tx.setGravity(Gravity.CENTER);
            box.addView(ic);box.addView(tx);
            LinearLayout.LayoutParams item=new LinearLayout.LayoutParams(0,dp(58),1);item.setMargins(dp(2),0,dp(2),0);
            nav.addView(box,item);box.setOnClickListener(v->switchTab(id));
        }
    }
    private void render(boolean resetScroll){
        if(cards==null)return;
        int old=resetScroll?0:scroll.getScrollY();
        cards.removeAllViews();orbit=null;
        drawNav();
        switch(tab){case 0:drawPlanet();break;case 1:drawSmelter();break;case 2:drawWorkshop();break;default:drawMissions();}
        scroll.post(()->scroll.scrollTo(0,old));
    }
    private void drawPlanet(){
        FrameLayout sceneBox=new FrameLayout(this);
        orbit=new OrbitView(this);sceneBox.addView(orbit,new FrameLayout.LayoutParams(-1,-1));
        cards.addView(sceneBox,margin(-1,205,14,10,14,10));sceneBox.setBackground(shape(SURFACE,16));sceneBox.setClipToOutline(true);
        LinearLayout stats=row();stats.setGravity(Gravity.CENTER_VERTICAL);
        TextView active=pill("●  "+game.opened()+" / 6 SITI",ACCENT,0xFF123C3B);
        stats.addView(active);
        TextView available=pill("◈  "+GameState.num(game.totalMined)+" ESTRATTI",GOLD,0xFF352D27);
        stats.addView(available,margin(-2,-2,10,0,0,0));
        cards.addView(stats,margin(-1,-2,18,0,14,7));
        sectionHeading("Siti di estrazione","Le macchine lavorano anche quando l'app è chiusa (fino a 8 ore).");
        for(int i=0;i<GameState.N;i++)drawMineCard(i);
    }
    private void drawMineCard(int i){
        final int id=i;
        LinearLayout card=panel();
        LinearLayout top=row();
        TextView symbol=txt(GameState.ICONS[i],16,GameState.COLORS[i],true);
        symbol.setGravity(Gravity.CENTER);symbol.setBackground(shape(0xFF1B3447,12));
        top.addView(symbol,margin(47,47,0,0,11,0));
        LinearLayout names=col();names.addView(txt(GameState.SITES[i],14,WHITE,true));
        names.addView(txt(GameState.ORES[i]+"  ·  "+GameState.VALUE[i]+" CR/unità",12,MUTED,false));
        top.addView(names,new LinearLayout.LayoutParams(0,-2,1));
        top.addView(pill(game.unlocked[i]?"ATTIVA":"BLOCCATA",game.unlocked[i]?ACCENT:GOLD,game.unlocked[i]?0xFF173932:0xFF393024));
        card.addView(top);
        if(!game.unlocked[i]){
            sub(card,"Nuova area di estrazione. Sbloccala con i crediti guadagnati.");
            actionLine(card,"SBLOCCA   ·   ◈ "+GameState.num(GameState.OPEN_COST[i]),game.credits>=GameState.OPEN_COST[i],true,()->successful(game.buyMine(id)));
            return;
        }
        line(card);
        LinearLayout qty=row();
        TextView left=txt("Estrazione  "+GameState.decimal(game.rate(i))+"/s",12,BLUE,true);
        TextView right=txt("Trasporto  "+GameState.decimal(game.transit(i))+"/s",12,ACCENT,true);
        qty.addView(left,new LinearLayout.LayoutParams(0,-2,1));qty.addView(right);
        card.addView(qty);
        double fill=Math.min(1,game.onSite[i]/game.cap(i));
        addMeter(card,(float)fill,GameState.COLORS[i]);
        sub(card,"Silo: "+GameState.num(game.onSite[i])+" / "+GameState.num(game.cap(i))+"     ·     In magazzino: "+GameState.num(game.raw[i]));
        dualButtons(card,"⛏ TRAPANO L"+game.drills[i]+"\n◈ "+GameState.num(game.drillPrice(i)),game.credits>=game.drillPrice(i),()->successful(game.buyUpgrade(id,0)),
                "➤ NAVETTA L"+game.drones[i]+"\n◈ "+GameState.num(game.dronePrice(i)),game.credits>=game.dronePrice(i),()->successful(game.buyUpgrade(id,1)));
        actionLine(card,"▣  SILO L"+game.silos[i]+"  ·  +18 SPAZIO  ·  ◈ "+GameState.num(game.siloPrice(i)),game.credits>=game.siloPrice(i),false,()->successful(game.buyUpgrade(id,2)));
    }
    private void addMeter(LinearLayout card,float progress,int color){
        FrameLayout base=new FrameLayout(this);base.setBackground(shape(0xFF233349,6));
        FrameLayout.LayoutParams fg=new FrameLayout.LayoutParams(-1,-1);
        View fill=new View(this);fill.setBackground(shape(color,6));
        // The parent is measured later; use weights in a 100-part LinearLayout for a stable progress bar.
        LinearLayout bar=row();bar.setBackground(shape(0xFF233349,6));
        View active=new View(this);active.setBackground(shape(color,6));
        if(progress>.001f){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,Math.max(.001f,progress));bar.addView(active,p);}
        if(progress<.999f){View empty=new View(this);bar.addView(empty,new LinearLayout.LayoutParams(0,-1,Math.max(.001f,1-progress)));}
        card.addView(bar,margin(-1,7,0,9,0,0));
    }
    private void drawSmelter(){
        sectionHeading("Fonderia orbitale","Vendi i materiali grezzi oppure trasformali in leghe più preziose.");
        LinearLayout banner=panel();banner.addView(title("4 minerali  →  1 lega"));
        sub(banner,"Una lega vale 5,5 volte il minerale grezzo. Raffinare conviene se puoi aspettare.");
        banner.addView(pill("PRODUZIONE MANUALE E AUTOMATICA",ACCENT,0xFF173932),margin(-2,-2,0,12,0,0));
        for(int i=0;i<GameState.N;i++)if(game.unlocked[i])drawResourceCard(i);
    }
    private void drawResourceCard(int i){
        final int id=i;
        LinearLayout p=panel();
        LinearLayout header=row();
        TextView badge=txt(GameState.ICONS[i],18,GameState.COLORS[i],true);badge.setBackground(shape(0xFF1B3447,10));badge.setGravity(Gravity.CENTER);
        header.addView(badge,margin(46,46,0,0,12,0));
        LinearLayout main=col();main.addView(txt(GameState.ORES[i],17,WHITE,true));
        main.addView(txt("Valore lega  ·  "+GameState.num(GameState.VALUE[i]*5.5)+" CR",12,GOLD,false));
        header.addView(main);p.addView(header);
        line(p);
        LinearLayout counts=row();
        LinearLayout a=col();a.addView(txt(GameState.num(game.raw[i]),24,WHITE,true));a.addView(txt("GREZZO",11,MUTED,true));
        LinearLayout b=col();b.addView(txt(GameState.num(game.ingots[i]),24,ACCENT,true));b.addView(txt("LEGHE",11,MUTED,true));
        counts.addView(a,new LinearLayout.LayoutParams(0,-2,1));counts.addView(b,new LinearLayout.LayoutParams(0,-2,1));p.addView(counts);
        actionLine(p,"⚗  RAFFINA 4 GREZZI IN 1 LEGA",game.raw[i]>=4,false,()->{if(game.refine(id,1)<1)toast("Servono 4 unità grezze");});
        dualButtons(p,"VENDI GREZZO\n◈ "+GameState.num(Math.floor(game.raw[i])*GameState.VALUE[i]),game.raw[i]>=1,()->{
            double sum=game.sell(id,false);toast("+"+GameState.num(sum)+" crediti");},
            "VENDI LEGHE\n◈ "+GameState.num(Math.floor(game.ingots[i])*GameState.VALUE[i]*5.5),game.ingots[i]>=1,()->{
            double sum=game.sell(id,true);toast("+"+GameState.num(sum)+" crediti");});
    }
    private void drawWorkshop(){
        sectionHeading("Officina e ricerca","Sviluppa tecnologia per rendere la tua colonia indipendente.");
        LinearLayout g=panel();g.addView(title("Centro tecnologico"));
        sub(g,"I miglioramenti globali agiscono su tutte le miniere attive.");
        line(g);
        g.addView(txt("TRAPANI AD ALTA ENERGIA   ·   L"+game.researchDrill,14,WHITE,true));
        sub(g,"+20% velocità di estrazione a ogni livello.");
        actionLine(g,"POTENZIA ESTRAZIONE  ·  ◈ "+GameState.num(game.researchDrillPrice()),game.credits>=game.researchDrillPrice(),true,()->successful(game.buyResearch(0)));
        line(g);
        g.addView(txt("ROTTE DI NAVIGAZIONE   ·   L"+game.researchTransit,14,WHITE,true));
        sub(g,"+20% velocità di trasporto a ogni livello.");
        actionLine(g,"POTENZIA TRASPORTO  ·  ◈ "+GameState.num(game.researchTransitPrice()),game.credits>=game.researchTransitPrice(),true,()->successful(game.buyResearch(1)));

        LinearLayout a=panel();a.addView(title("Automazione"));
        sub(a,"Sblocca questi sistemi una volta sola, con i crediti guadagnati giocando.");
        line(a);
        a.addView(txt("COMMERCIO AUTOMATICO",14,WHITE,true));
        sub(a,"Vende il contenuto dei magazzini ogni 12 secondi, anche durante le ore offline.");
        if(!game.autoSellOwned){
            actionLine(a,"SBLOCCA  ·  ◈ 2.900",game.credits>=2900,true,()->successful(game.buyAutomation(0)));
        }else{
            actionLine(a,"VENDITA AUTOMATICA  ·  "+(game.autoSell?"ATTIVA":"IN PAUSA"),true,game.autoSell,()->game.autoSell=!game.autoSell);
        }
        line(a);
        a.addView(txt("FONDERIA AUTOMATICA",14,WHITE,true));
        sub(a,"Trasforma automaticamente le risorse grezze in leghe. Puoi interromperla quando vuoi.");
        if(!game.autoRefineOwned){
            actionLine(a,"SBLOCCA  ·  ◈ 4.700",game.credits>=4700,true,()->successful(game.buyAutomation(1)));
        }else{
            actionLine(a,"RAFFINAZIONE AUTOMATICA  ·  "+(game.autoRefine?"ATTIVA":"IN PAUSA"),true,game.autoRefine,()->game.autoRefine=!game.autoRefine);
        }
        LinearLayout info=panel();info.addView(txt("DATI E PRIVACY",14,ACCENT,true));
        sub(info,"PossMiner funziona senza internet. Non contiene pubblicità, acquisti integrati, analytics o tracciamento. I progressi restano sul dispositivo.");
        actionLine(info,"RICOMINCIA PARTITA (CONFERMA)",true,false,()->new AlertDialog.Builder(this)
                .setTitle("Ricominciare da zero?")
                .setMessage("Tutti i progressi di PossMiner saranno eliminati. Questa operazione non si può annullare.")
                .setNegativeButton("ANNULLA",(d,w)->{})
                .setPositiveButton("RICOMINCIA",(d,w)->{game=new GameState();game.save(this);render(true);})
                .show());
    }
    private void drawMissions(){
        sectionHeading("Missioni","Completa gli obiettivi e riscuoti premi senza guardare pubblicità.");
        LinearLayout card=panel();
        if(game.mission>=GameState.MISSION_NAMES.length){
            card.addView(title("★  Tutte le missioni completate"));sub(card,"Hai raggiunto tutti gli obiettivi disponibili in questa versione!");
        }else{
            card.addView(pill("MISSIONE "+(game.mission+1)+" / "+GameState.MISSION_NAMES.length,ACCENT,0xFF173932),margin(-2,-2,0,0,0,12));
            card.addView(title(GameState.MISSION_NAMES[game.mission]));
            sub(card,GameState.MISSION_DESCS[game.mission]);
            double need=GameState.MISSION_GOALS[game.mission],have=Math.min(need,game.missionProgress());
            card.addView(txt(GameState.num(have)+" / "+GameState.num(need),18,BLUE,true),margin(-1,-2,0,13,0,0));
            addMeter(card,(float)Math.max(0,Math.min(1,have/need)),ACCENT);
            sub(card,"RICOMPENSA  ·  ◈  "+GameState.num(GameState.MISSION_REWARDS[game.mission])+" crediti");
            actionLine(card,game.missionReady()?"RISCUOTI RICOMPENSA":"OBIETTIVO NON ANCORA RAGGIUNTO",game.missionReady(),true,()->{
                double prize=game.claimMission();toast("Missione completata! +"+GameState.num(prize)+" CR");});
        }
        LinearLayout stats=panel();stats.addView(title("Diario della colonia"));line(stats);
        stat(stats,"Crediti guadagnati",GameState.num(game.totalEarned));
        stat(stats,"Minerali estratti",GameState.num(game.totalMined));
        stat(stats,"Unità vendute",GameState.num(game.totalSold));
        stat(stats,"Leghe raffinate",GameState.num(game.totalRefined));
        stat(stats,"Potenziamenti acquistati",GameState.num(game.upgrades));
        stat(stats,"Siti sbloccati",game.opened()+" / 6");
        stat(stats,"Missioni completate",game.mission+" / "+GameState.MISSION_NAMES.length);
        LinearLayout how=panel();how.addView(title("Come si gioca"));
        sub(how,"1. I siti estraggono automaticamente minerali.");
        sub(how,"2. Le navette spostano i minerali in magazzino.");
        sub(how,"3. Nella Fonderia puoi vendere le risorse o trasformarle in leghe.");
        sub(how,"4. Usa i crediti per sbloccare nuovi giacimenti, ricerche e automazioni.");
        sub(how,"5. Ottieni ricompense completando le missioni.");
    }
    private void stat(LinearLayout parent,String name,String value){
        LinearLayout r=row();TextView a=txt(name,13,MUTED,false),b=txt(value,14,WHITE,true);
        r.addView(a,new LinearLayout.LayoutParams(0,-2,1));r.addView(b);
        parent.addView(r,margin(-1,-2,0,7,0,7));
    }
}
