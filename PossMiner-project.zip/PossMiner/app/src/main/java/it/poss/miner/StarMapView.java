package it.poss.miner;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import java.util.Random;

/** Entirely generated, original clickable orbital map; contains no images or third party assets. */
public class StarMapView extends View {
  interface Listener { void onDeposit(int index); }
  private final Paint p=new Paint(3);
  private final Random rand=new Random(4619921);
  private FrontierGame game;
  private Listener listener;
  private double spin=0;
  private final float[] starsX=new float[85],starsY=new float[85],starsRad=new float[85];
  public StarMapView(Context context,FrontierGame g){super(context);game=g;
    for(int i=0;i<starsX.length;i++){starsX[i]=rand.nextFloat();starsY[i]=rand.nextFloat();starsRad[i]=.4f+rand.nextFloat()*1.3f;}
    setLayerType(View.LAYER_TYPE_SOFTWARE,null);
  }
  public void setListener(Listener value){listener=value;}
  public void progress(){spin+=0.009;invalidate();}
  private float cx(){return getWidth()/2f;}
  private float cy(){return getHeight()*.49f;}
  private float core(){return Math.min(getWidth(),getHeight())*.255f;}
  private float[] coordinate(int i){float w=getWidth(),h=getHeight();
    float ang=(float)(i*2.3999632+spin*.10-0.25);
    float r=Math.min(w,h)*(.35f+(i%3)*.049f);
    return new float[]{cx()+(float)Math.cos(ang)*r,cy()+(float)Math.sin(ang)*r*.57f};}
  @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
    float w=getWidth(),h=getHeight();int tint=game.planetColor();
    p.setShader(null);p.setColor(0xFF08172B);canvas.drawColor(0xFF091B30);
    p.setColor(0xFF16314B);canvas.drawRoundRect(new RectF(0,0,w,h),24,24,p);
    for(int i=0;i<starsX.length;i++){
      float tw=(float)(Math.sin(spin*3+i)*.3+0.7);
      p.setColor(Color.argb((int)(35+105*tw),185,220,239));
      canvas.drawCircle(starsX[i]*w,starsY[i]*h,starsRad[i]*tw,p);
    }
    float x=cx(),y=cy(),r=core();
    p.setStyle(Paint.Style.FILL);
    p.setShader(new RadialGradient(x-r*.3f,y-r*.45f,r*1.9f,new int[]{lighten(tint),dim(tint),0xFF101E37},null,Shader.TileMode.CLAMP));
    canvas.drawCircle(x,y,r,p);p.setShader(null);
    p.setColor(0x35000000);canvas.drawOval(new RectF(x-r*.55f,y-r*.47f,x+r*.85f,y-r*.1f),p);
    p.setColor(0x321C2934);canvas.drawOval(new RectF(x-r*.84f,y+r*.2f,x+r*.75f,y+r*.53f),p);
    p.setColor(0x1BFFFFFF);canvas.drawCircle(x-r*.32f,y-r*.34f,r*.19f,p);
    p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.6f);p.setColor(0x668ED9E0);
    RectF arc=new RectF(x-w*.46f,y-h*.29f,x+w*.46f,y+h*.29f);
    canvas.save();canvas.rotate(-18,x,y);canvas.drawOval(arc,p);p.setColor(0x226AC1D1);
    canvas.drawOval(new RectF(x-w*.46f-12,y-h*.29f-12,x+w*.46f+12,y+h*.29f+12),p);canvas.restore();
    p.setStyle(Paint.Style.FILL);
    for(int i=0;i<FrontierGame.DEPOSITS;i++){
      float[] at=coordinate(i);
      if(!game.open[i] && i>game.opened()+1)continue;
      boolean active=game.open[i];boolean selected=i==game.selectedMine;
      p.setColor(active?0x5544F0CF:0x44B3D0DF);canvas.drawCircle(at[0],at[1],selected?17:13,p);
      p.setColor(active?0xFF69E7C7:0xFF677C95);canvas.drawCircle(at[0],at[1],selected?9:7,p);
      p.setColor(active?0xFF0E2539:0xFF172439);canvas.drawCircle(at[0],at[1],3.6f,p);
      if(selected){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.2f);p.setColor(0xFFFED47A);canvas.drawCircle(at[0],at[1],22,p);p.setStyle(Paint.Style.FILL);}
      if(active && game.flight[i]>0){
        float f=(float)Math.min(1,game.flight[i]/Math.max(1,game.tripDuration(i)));
        p.setColor(0xFFA8EAFF);canvas.drawCircle(at[0]+(x-at[0])*(1-f),at[1]+(y-at[1])*(1-f),3.2f,p);
      }
    }
    p.setColor(0xFFFFFFFF);p.setTextSize(19);p.setFakeBoldText(true);p.setTextAlign(Paint.Align.LEFT);
    canvas.drawText(game.planetName(),18,31,p);p.setFakeBoldText(false);
    p.setTextSize(11);p.setColor(0xFF91BDCC);canvas.drawText("ZONA DI ESTRAZIONE  •  PIANETA "+(game.planet+1),18,49,p);
    p.setColor(0xFFE1F9FF);p.setTextAlign(Paint.Align.RIGHT);p.setTextSize(11);
    canvas.drawText("TOCCA UN GIACIMENTO",w-14,h-15,p);
  }
  private int lighten(int rgb){return Color.rgb(Math.min(255,Color.red(rgb)+53),Math.min(255,Color.green(rgb)+50),Math.min(255,Color.blue(rgb)+47));}
  private int dim(int rgb){return Color.rgb(Math.max(10,Color.red(rgb)/3),Math.max(20,Color.green(rgb)/3),Math.max(30,Color.blue(rgb)/3));}
  @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN)return true;
    if(e.getAction()==MotionEvent.ACTION_UP){
      int best=-1;double dist=1e10;
      for(int i=0;i<FrontierGame.DEPOSITS;i++){float[] at=coordinate(i);double d=Math.hypot(e.getX()-at[0],e.getY()-at[1]);if(d<dist){best=i;dist=d;}}
      if(best>=0&&dist<45&&listener!=null){listener.onDeposit(best);performClick();}
      return true;
    }return super.onTouchEvent(e);
  }
  @Override public boolean performClick(){super.performClick();return true;}
}
